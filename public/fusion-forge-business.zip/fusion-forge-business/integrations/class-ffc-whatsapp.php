<?php
/**
 * WhatsApp Business API & Web Link Composer
 */

class FFC_WhatsApp {

    public static function init() {
        // Init whatsapp filters
    }

    /**
     * Composes clean WhatsApp message text for business documents
     */
    public static function compose_document_message($doc_type, $doc_data, $seller_profile = null) {
        if (!$seller_profile) {
            $seller_profile = FFC_DB::get_seller_profile();
        }

        $company = $seller_profile['company_name'] ?? 'Fusion Forge Creations';
        $client_name = $doc_data['client_name'] ?? $doc_data['supplier_name'] ?? 'Valued Client';
        $num = $doc_data['doc_number'] ?? $doc_data['invoice_number'] ?? $doc_data['quotation_number'] ?? $doc_data['receipt_number'] ?? $doc_data['note_number'] ?? '';
        $amount = number_format(floatval($doc_data['total_amount'] ?? $doc_data['amount'] ?? 0), 2);

        $titles = [
            'quotation' => 'Quotation & Project Scope',
            'invoice' => 'Tax Invoice',
            'payment_receipt' => 'Official Payment Receipt',
            'purchase_order' => 'Purchase Order',
            'credit_note' => 'Credit Note',
            'debit_note' => 'Debit Note'
        ];

        $title = $titles[$doc_type] ?? 'Business Document';

        $text = "Greetings {$client_name},\n\n";
        $text .= "Please find the details of your *{$title}* from *{$company}*:\n\n";
        $text .= "📄 *Document No:* {$num}\n";
        $text .= "💰 *Total Amount:* ₹{$amount}\n";
        
        if (!empty($doc_data['due_date'])) {
            $text .= "📅 *Due Date:* {$doc_data['due_date']}\n";
        }
        if (!empty($doc_data['payment_terms'])) {
            $text .= "📝 *Terms:* {$doc_data['payment_terms']}\n";
        }

        $text .= "\nFor any assistance or questions, please feel free to reach us.\n";
        $text .= "Thank you for partnering with *{$company}*.\n";
        $text .= "🌐 " . ($seller_profile['website'] ?? 'https://fusionforgecreation.com');

        return $text;
    }

    /**
     * Generates a WhatsApp Web link for direct sending
     */
    public static function get_whatsapp_web_url($phone_number, $message) {
        $clean_phone = preg_replace('/[^0-9]/', '', $phone_number);
        // If 10 digits Indian phone, prefix 91
        if (strlen($clean_phone) === 10) {
            $clean_phone = '91' . $clean_phone;
        }

        return 'https://api.whatsapp.com/send?phone=' . urlencode($clean_phone) . '&text=' . rawurlencode($message);
    }
}
