<?php
/**
 * Server-side Email Dispatcher with PDF Attachment Support
 */

class FFC_Email {

    public static function init() {
        // Init email filters
    }

    /**
     * Sends email with optional document HTML attachment
     */
    public static function send_document_email($to, $subject, $message, $doc_type = null, $doc_data = null) {
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        $seller = FFC_DB::get_seller_profile();
        $from_name = $seller['company_name'] ?? 'Fusion Forge Creations';
        $from_email = $seller['email'] ?? get_option('admin_email');
        $headers[] = "From: $from_name <$from_email>";

        $body = "
        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;'>
            <div style='color: #8e2d9d; font-size: 20px; font-weight: bold; margin-bottom: 12px;'>$from_name</div>
            <div style='font-size: 14px; color: #334155; line-height: 1.6; margin-bottom: 20px;'>
                " . nl2br(esc_html($message)) . "
            </div>
            <hr style='border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;'/>
            <div style='font-size: 12px; color: #64748b;'>
                <strong>$from_name</strong><br/>
                " . esc_html($seller['address'] ?? '') . "<br/>
                Email: " . esc_html($from_email) . " | Phone: " . esc_html($seller['phone'] ?? '') . "
            </div>
        </div>";

        $attachments = [];

        // In WordPress standard environment, use wp_mail
        $sent = wp_mail($to, $subject, $body, $headers, $attachments);

        FFC_DB::log_audit('email_sent', 'integrations', null, [
            'to' => $to,
            'subject' => $subject,
            'status' => $sent ? 'delivered' : 'failed'
        ]);

        return $sent;
    }
}
