<?php
/**
 * Plugin Name: Fusion Forge Business Management & ERP
 * Plugin URI: https://fusionforgecreation.com/
 * Description: Production-ready enterprise ERP, Party Ledgers, GST Engine, Quotations, Invoices, Purchases, Payroll, Attendance, Registers and Common Document Engine for Fusion Forge Creations.
 * Version: 2.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Fusion Forge Creations
 * Author URI: https://fusionforgecreation.com/
 * License: Proprietary
 * Text Domain: fusion-forge-business
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('FFC_VERSION', '2.0.0');
define('FFC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FFC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FFC_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Autoloader for Fusion Forge Classes
 */
spl_autoload_register(function ($class) {
    $prefix = 'FFC_';
    $base_dir = FFC_PLUGIN_DIR;

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = strtolower(str_replace('_', '-', substr($class, $len)));
    
    $paths = [
        $base_dir . 'includes/class-ffc-' . $relative_class . '.php',
        $base_dir . 'database/class-ffc-' . $relative_class . '.php',
        $base_dir . 'auth/class-ffc-' . $relative_class . '.php',
        $base_dir . 'accounting/class-ffc-' . $relative_class . '.php',
        $base_dir . 'documents/class-ffc-' . $relative_class . '.php',
        $base_dir . 'integrations/class-ffc-' . $relative_class . '.php',
        $base_dir . 'reports/class-ffc-' . $relative_class . '.php',
        $base_dir . 'api/class-ffc-' . $relative_class . '.php',
        $base_dir . 'admin/class-ffc-' . $relative_class . '.php',
        $base_dir . 'migrations/class-ffc-' . $relative_class . '.php',
    ];

    foreach ($paths as $file) {
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Explicit Includes
require_once FFC_PLUGIN_DIR . 'includes/class-ffc-activator.php';
require_once FFC_PLUGIN_DIR . 'includes/class-ffc-deactivator.php';
require_once FFC_PLUGIN_DIR . 'database/class-ffc-db.php';
require_once FFC_PLUGIN_DIR . 'auth/class-ffc-auth.php';
require_once FFC_PLUGIN_DIR . 'auth/class-ffc-rbac.php';
require_once FFC_PLUGIN_DIR . 'auth/class-ffc-totp.php';
require_once FFC_PLUGIN_DIR . 'accounting/class-ffc-gst-engine.php';
require_once FFC_PLUGIN_DIR . 'accounting/class-ffc-ledger.php';
require_once FFC_PLUGIN_DIR . 'accounting/class-ffc-registers.php';
require_once FFC_PLUGIN_DIR . 'accounting/class-ffc-payroll.php';
require_once FFC_PLUGIN_DIR . 'documents/class-ffc-numbering.php';
require_once FFC_PLUGIN_DIR . 'documents/class-ffc-document-engine.php';
require_once FFC_PLUGIN_DIR . 'integrations/class-ffc-email.php';
require_once FFC_PLUGIN_DIR . 'integrations/class-ffc-whatsapp.php';
require_once FFC_PLUGIN_DIR . 'reports/class-ffc-reports.php';
require_once FFC_PLUGIN_DIR . 'api/class-ffc-rest-api.php';
require_once FFC_PLUGIN_DIR . 'admin/class-ffc-admin.php';

/**
 * The code that runs during plugin activation.
 */
function activate_fusion_forge_business() {
    FFC_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_fusion_forge_business() {
    FFC_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_fusion_forge_business');
register_deactivation_hook(__FILE__, 'deactivate_fusion_forge_business');

/**
 * Begins execution of the plugin.
 */
function run_fusion_forge_business() {
    // Initialize Database
    FFC_DB::init();

    // Initialize Auth & RBAC
    FFC_Auth::init();
    FFC_RBAC::init();

    // Initialize REST APIs
    FFC_REST_API::init();

    // Initialize Admin Controller
    FFC_Admin::init();

    // Initialize Integrations
    FFC_Email::init();
    FFC_WhatsApp::init();
}

add_action('plugins_loaded', 'run_fusion_forge_business');
