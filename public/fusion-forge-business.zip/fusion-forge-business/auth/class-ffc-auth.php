<?php
/**
 * Authentication and Session Handler Class
 */

class FFC_Auth {

    const SESSION_KEY = 'ffc_auth_session';

    public static function init() {
        if (!session_id() && !headers_sent()) {
            session_start();
        }
    }

    public static function get_current_user() {
        if (!empty($_SESSION[self::SESSION_KEY])) {
            return $_SESSION[self::SESSION_KEY];
        }

        // Also check if current WordPress user is logged in
        if (is_user_logged_in()) {
            $wp_user = wp_get_current_user();
            return self::get_or_create_from_wp_user($wp_user);
        }

        return null;
    }

    public static function login($email, $password, $totp_code = null) {
        global $wpdb;
        $table = FFC_DB::get_table('users');

        $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE email = %s AND status = 'active'", $email), ARRAY_A);
        if (!$user) {
            // Check WordPress core users as fallback
            $wp_user = get_user_by('email', $email);
            if ($wp_user && wp_check_password($password, $wp_user->user_pass, $wp_user->ID)) {
                $user = self::get_or_create_from_wp_user($wp_user);
            } else {
                return new WP_Error('invalid_credentials', 'Invalid email or password.');
            }
        } else {
            if (!wp_check_password($password, $user['password_hash'])) {
                return new WP_Error('invalid_credentials', 'Invalid email or password.');
            }
        }

        // Check 2FA if enabled
        if (!empty($user['totp_enabled']) && !empty($user['totp_secret'])) {
            if (empty($totp_code)) {
                return [
                    'requires_2fa' => true,
                    'user_id' => $user['id'],
                    'message' => 'Please provide 6-digit Google Authenticator 2FA code.'
                ];
            }

            if (!FFC_TOTP::verify($user['totp_secret'], $totp_code)) {
                return new WP_Error('invalid_2fa', 'Invalid 2FA code. Please check your authenticator app.');
            }
        }

        // Set session
        $session_data = [
            'id' => $user['id'],
            'email' => $user['email'],
            'name' => $user['name'],
            'role' => $user['role'],
            'custom_permissions' => $user['custom_permissions'] ?? null,
            'avatar_url' => $user['avatar_url'] ?? '',
            'logged_in_at' => time()
        ];

        $_SESSION[self::SESSION_KEY] = $session_data;

        $wpdb->update($table, ['last_login' => current_time('mysql')], ['id' => $user['id']]);
        FFC_DB::log_audit('login', 'auth', $user['id'], 'User logged into ERP Portal', $user['id'], $user['email']);

        return $session_data;
    }

    public static function logout() {
        if (!empty($_SESSION[self::SESSION_KEY])) {
            $u = $_SESSION[self::SESSION_KEY];
            FFC_DB::log_audit('logout', 'auth', $u['id'], 'User logged out', $u['id'], $u['email']);
            unset($_SESSION[self::SESSION_KEY]);
        }
        return true;
    }

    private static function get_or_create_from_wp_user($wp_user) {
        global $wpdb;
        $table = FFC_DB::get_table('users');

        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE email = %s", $wp_user->user_email), ARRAY_A);
        if ($existing) {
            return $existing;
        }

        $role = in_array('administrator', $wp_user->roles) ? 'super_admin' : 'staff';
        $user_id = 'user_' . uniqid();

        $wpdb->insert($table, [
            'id' => $user_id,
            'wp_user_id' => $wp_user->ID,
            'email' => $wp_user->user_email,
            'password_hash' => $wp_user->user_pass,
            'name' => $wp_user->display_name ?: $wp_user->user_nicename,
            'role' => $role,
            'status' => 'active',
            'created_at' => current_time('mysql')
        ]);

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %s", $user_id), ARRAY_A);
    }
}
