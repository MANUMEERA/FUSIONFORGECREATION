<?php
/**
 * TOTP / Google Authenticator Class (RFC 6238 Standard)
 */

class FFC_TOTP {

    private static $base32_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function generate_secret($length = 16) {
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= self::$base32_chars[random_int(0, 31)];
        }
        return $secret;
    }

    public static function get_otp($secret, $time_slice = null) {
        if ($time_slice === null) {
            $time_slice = floor(time() / 30);
        }

        $secret_key = self::base32_decode($secret);
        $time_packed = pack('N*', 0) . pack('N*', $time_slice);
        $hmac = hash_hmac('sha1', $time_packed, $secret_key, true);
        $offset = ord(substr($hmac, -1)) & 0x0F;
        $hash_part = substr($hmac, $offset, 4);
        $value = unpack('N', $hash_part);
        $value = $value[1] & 0x7FFFFFFF;
        $modulo = pow(10, 6);
        return str_pad($value % $modulo, 6, '0', STR_PAD_LEFT);
    }

    public static function verify($secret, $code, $discrepancy = 1) {
        $currentTimeSlice = floor(time() / 30);
        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            $calculatedOtp = self::get_otp($secret, $currentTimeSlice + $i);
            if (hash_equals($calculatedOtp, (string)$code)) {
                return true;
            }
        }
        return false;
    }

    public static function get_qr_uri($company_name, $account_name, $secret) {
        $encoded_issuer = rawurlencode($company_name);
        $encoded_account = rawurlencode($account_name);
        return "otpauth://totp/{$encoded_issuer}:{$encoded_account}?secret={$secret}&issuer={$encoded_issuer}&algorithm=SHA1&digits=6&period=30";
    }

    private static function base32_decode($secret) {
        if (empty($secret)) return '';
        $secret = strtoupper($secret);
        $buffer = 0;
        $bufferSize = 0;
        $result = '';

        for ($i = 0; $i < strlen($secret); $i++) {
            $char = $secret[$i];
            $position = strpos(self::$base32_chars, $char);
            if ($position === false) continue;

            $buffer = ($buffer << 5) | $position;
            $bufferSize += 5;

            if ($bufferSize >= 8) {
                $bufferSize -= 8;
                $result .= chr(($buffer >> $bufferSize) & 0xFF);
            }
        }
        return $result;
    }
}
