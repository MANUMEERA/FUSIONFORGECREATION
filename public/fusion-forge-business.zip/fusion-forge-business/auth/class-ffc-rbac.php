<?php
/**
 * Role-Based Access Control (RBAC) Class
 */

class FFC_RBAC {

    public static function init() {
        // Init RBAC
    }

    public static function get_roles() {
        global $wpdb;
        $table = FFC_DB::get_table('roles');
        return $wpdb->get_results("SELECT * FROM $table ORDER BY name ASC", ARRAY_A);
    }

    public static function get_role_permissions($role_id) {
        global $wpdb;
        $table = FFC_DB::get_table('roles');
        $perms = $wpdb->get_var($wpdb->prepare("SELECT permissions FROM $table WHERE id = %s", $role_id));
        if ($perms) {
            $decoded = json_decode($perms, true);
            return is_array($decoded) ? $decoded : [];
        }
        return [];
    }

    public static function user_can($user, $permission) {
        if (!$user) return false;

        $role = $user['role'] ?? 'staff';
        if ($role === 'super_admin') {
            return true; // Unrestricted access for Super Admin
        }

        // Custom permissions on user record override or augment role
        if (!empty($user['custom_permissions'])) {
            $custom = json_decode($user['custom_permissions'], true);
            if (is_array($custom) && in_array($permission, $custom)) {
                return true;
            }
        }

        $role_perms = self::get_role_permissions($role);
        return in_array($permission, $role_perms);
    }
}
