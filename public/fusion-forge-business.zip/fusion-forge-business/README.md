# Fusion Forge Business Management & ERP (WordPress Plugin)

**Version:** 2.0.0  
**License:** Proprietary  
**Author:** Fusion Forge Creations  
**Compatibility:** WordPress 5.8+ | PHP 7.4 - 8.3+ | MySQL 5.7+ / MariaDB 10.3+

---

## 🚀 Overview

The **Fusion Forge Business Management & ERP** plugin transforms any standard WordPress installation into a full-fledged, high-concurrency enterprise business ERP tailored specifically for Indian tax regulations (GST/CGST/SGST/IGST/UTGST), professional service agencies, digital agencies, and trading enterprises.

---

## ✨ Core Features & Architecture

### 1. 🏢 Complete Entity & Party Management
- **Company / Seller Master**: Full multi-line address, GSTIN, PAN, MSME, LUT number/expiry, Bank Accounts, UPI ID with QR string generator, official seals, and custom terms.
- **Client & Vendor Directories**: Normalized records with separate billing/shipping addresses, GSTIN state code verification, balance tracking, and credit terms.

### 2. 📑 Document Engine (Financial Year Based Numbering)
- **Quotations / Estimates**: `FFC/QT/{YY}-{YY+1}/{SEQ}` with validity periods, milestone schedules, and one-click conversion to Tax Invoice.
- **Tax Invoices**: `FFC/INV/{YY}-{YY+1}/{SEQ}` strictly formatted for Indian GST compliance with B2B/B2C logic, SAC/HSN codes, and reverse charge handling.
- **Credit Notes / Debit Notes**: Linked directly to original invoice IDs with statutory reason codes.
- **Purchase Orders & Bills**: Complete vendor tracking, incoming tax breakdown, and inventory costing.
- **Payment Receipts**: Integrated with bank accounts, cash registers, and client ledger accounts.

### 3. 🇮🇳 Indian Tax & GST Engine
- Real-time detection of Intra-State (`CGST` + `SGST`), Inter-State (`IGST`), and Union Territory (`UTGST` for Dadra & Nagar Haveli / Daman & Diu - State Code `26`).
- Reverse Charge Mechanism (`RCM`) handling and export under LUT without tax payment.
- Indian Numbering Format (`₹ Lakhs / Crores`) and number-to-words currency translation in standard Indian English (`Lakhs / Crores`).

### 4. 📒 Triple-Entry Ledger & Registers
- **General Double-Entry Ledger**: Chart of accounts, journal entries, vouchers, and auto-balancing debit/credit validation.
- **Sales & Purchase Registers**: Monthly, quarterly, and annual GST tax computation for GSTR-1, GSTR-3B, and GSTR-2B reconciliation.
- **Bank & Cash Books**: Daily cash float, petty cash reconciliation, and live balances.

### 5. 👥 Human Resources, Attendance & Payroll
- **Staff Profiles**: Designation, Department, Date of Joining, Bank Details, PAN, UAN, and EPF/ESI eligibility.
- **Punch In/Out Attendance**: Present, Absent, Half Day, Leave with Pay (`LWP`), and overtime calculation.
- **Automated Salary Slips**: Basic, HRA, Special Allowance, PF deduction, Professional Tax (PT), TDS, and Net Pay computation.

### 6. 🔐 Enterprise RBAC & Two-Factor Authentication (2FA)
- Time-based One-Time Password (TOTP) compatible with Google Authenticator, Microsoft Authenticator, and 1Password.
- Fine-grained role permissions: `Super Admin`, `Accountant`, `Project Manager`, `HR Executive`, `Sales Staff`.

### 7. 📲 Direct WhatsApp & Email Dispatch
- Direct integration with WhatsApp Business API / Cloud API for automated invoice delivery.
- SMTP / WordPress `wp_mail` integration with PDF attachments and delivery logging.

---

## 🛠️ Installation & Setup

1. Compress the `fusion-forge-business` folder into a `.zip` file: `fusion-forge-business.zip`.
2. In your WordPress Admin Dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3. Select `fusion-forge-business.zip` and click **Install Now**.
4. Activate the plugin. The database tables (`wp_ffc_*`) and default settings will be created automatically via `dbDelta()`.
5. Access the new **Fusion Forge ERP** menu on the WordPress admin sidebar.

---

## 📡 REST API Endpoints (`/wp-json/ffc/v1/`)

All endpoints require standard WordPress REST API authentication (`X-WP-Nonce` header or Application Password / JWT):

| Endpoint | Method | Description |
| :--- | :--- | :--- |
| `/ffc/v1/dashboard` | `GET` | Real-time financial metrics, receivables, payables, and pipeline stats |
| `/ffc/v1/clients` | `GET`, `POST` | List and create client profiles |
| `/ffc/v1/quotations` | `GET`, `POST` | Fetch quotes, create new estimates, and convert to invoice |
| `/ffc/v1/invoices` | `GET`, `POST` | Full invoice lifecycle, GST tax calculations, and status tracking |
| `/ffc/v1/payments` | `GET`, `POST` | Record client payments and generate payment vouchers |
| `/ffc/v1/ledger` | `GET` | Access party statement of accounts and chart of accounts |
| `/ffc/v1/payroll` | `GET`, `POST` | Manage staff payroll, attendance records, and pay slips |
| `/ffc/v1/reports/gstr1` | `GET` | Generate GSTR-1 summary for B2B, B2CS, and Credit Notes |

---

## 🗄️ Database Tables (`wp_ffc_*`)

The plugin creates 20 dedicated, high-performance normalized tables:
- `wp_ffc_roles` & `wp_ffc_users` (RBAC & 2FA)
- `wp_ffc_seller_profile` (Company master)
- `wp_ffc_clients` & `wp_ffc_vendors` (Party master)
- `wp_ffc_quotations` & `wp_ffc_quotation_items`
- `wp_ffc_invoices` & `wp_ffc_invoice_items`
- `wp_ffc_credit_notes` & `wp_ffc_credit_note_items`
- `wp_ffc_purchases` & `wp_ffc_purchase_items`
- `wp_ffc_payments` & `wp_ffc_accounts`
- `wp_ffc_ledger_entries`
- `wp_ffc_employees`, `wp_ffc_attendance`, `wp_ffc_payroll`
- `wp_ffc_activity_logs` & `wp_ffc_communication_logs`

---

*Fusion Forge Creations — All Rights Reserved.*
