<?php
/**
 * Reports and Financial Analytics Engine
 */

class FFC_Reports {

    /**
     * Outstanding Receivables (Unpaid Invoices)
     */
    public static function get_receivables($filters = []) {
        global $wpdb;

        $table = FFC_DB::get_table('invoices');
        $where = ["balance_due > 0"];
        $params = [];

        if (!empty($filters['client_id'])) {
            $where[] = "client_id = %s";
            $params[] = $filters['client_id'];
        }

        $sql = "SELECT id, invoice_number, client_name, client_company, issue_date, due_date, total_amount, amount_paid, balance_due, status FROM $table WHERE " . implode(' AND ', $where) . " ORDER BY due_date ASC";
        $results = !empty($params) ? $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);

        $total_outstanding = array_sum(array_column($results, 'balance_due'));

        return [
            'rows' => $results,
            'total_outstanding' => round($total_outstanding, 2),
            'count' => count($results)
        ];
    }

    /**
     * Financial Profit & Loss and Cashflow Summary
     */
    public static function get_financial_summary($from_date = null, $to_date = null) {
        global $wpdb;

        // Total Invoiced Sales
        $table_inv = FFC_DB::get_table('invoices');
        $inv_where = ["1=1"];
        $inv_params = [];
        if ($from_date) { $inv_where[] = "issue_date >= %s"; $inv_params[] = $from_date; }
        if ($to_date) { $inv_where[] = "issue_date <= %s"; $inv_params[] = $to_date; }
        $inv_sql = "SELECT SUM(taxable_amount) as taxable, SUM(total_tax) as tax, SUM(total_amount) as total, SUM(amount_paid) as collected, SUM(balance_due) as due FROM $table_inv WHERE " . implode(' AND ', $inv_where);
        $sales = !empty($inv_params) ? $wpdb->get_row($wpdb->prepare($inv_sql, ...$inv_params), ARRAY_A) : $wpdb->get_row($inv_sql, ARRAY_A);

        // Purchases
        $table_pur = FFC_DB::get_table('purchases');
        $pur_where = ["1=1"];
        $pur_params = [];
        if ($from_date) { $pur_where[] = "bill_date >= %s"; $pur_params[] = $from_date; }
        if ($to_date) { $pur_where[] = "bill_date <= %s"; $pur_params[] = $to_date; }
        $pur_sql = "SELECT SUM(taxable_amount) as taxable, SUM(total_tax) as tax, SUM(total_amount) as total FROM $table_pur WHERE " . implode(' AND ', $pur_where);
        $purchases = !empty($pur_params) ? $wpdb->get_row($wpdb->prepare($pur_sql, ...$pur_params), ARRAY_A) : $wpdb->get_row($pur_sql, ARRAY_A);

        // Expenses
        $table_exp = FFC_DB::get_table('expenses');
        $exp_where = ["1=1"];
        $exp_params = [];
        if ($from_date) { $exp_where[] = "expense_date >= %s"; $exp_params[] = $from_date; }
        if ($to_date) { $exp_where[] = "expense_date <= %s"; $exp_params[] = $to_date; }
        $exp_sql = "SELECT SUM(amount) as total FROM $table_exp WHERE " . implode(' AND ', $exp_where);
        $expenses = !empty($exp_params) ? $wpdb->get_row($wpdb->prepare($exp_sql, ...$exp_params), ARRAY_A) : $wpdb->get_row($exp_sql, ARRAY_A);

        // Payroll
        $table_sal = FFC_DB::get_table('salary_records');
        $sal_sql = "SELECT SUM(gross_salary) as gross, SUM(net_salary) as net FROM $table_sal";
        $salaries = $wpdb->get_row($sal_sql, ARRAY_A);

        $gross_revenue = floatval($sales['taxable'] ?? 0);
        $total_costs = floatval($purchases['taxable'] ?? 0) + floatval($expenses['total'] ?? 0) + floatval($salaries['gross'] ?? 0);
        $operating_profit = $gross_revenue - $total_costs;

        return [
            'gross_sales_taxable' => round($gross_revenue, 2),
            'total_sales_with_tax' => round(floatval($sales['total'] ?? 0), 2),
            'total_collected' => round(floatval($sales['collected'] ?? 0), 2),
            'total_receivables_due' => round(floatval($sales['due'] ?? 0), 2),
            'total_purchases' => round(floatval($purchases['taxable'] ?? 0), 2),
            'total_operating_expenses' => round(floatval($expenses['total'] ?? 0), 2),
            'total_payroll' => round(floatval($salaries['gross'] ?? 0), 2),
            'operating_profit' => round($operating_profit, 2),
            'net_profit_margin' => $gross_revenue > 0 ? round(($operating_profit / $gross_revenue) * 100, 2) : 0
        ];
    }
}
