<?php
/**
 * Fired when the plugin is uninstalled.
 */

// If uninstall not called from WordPress, then exit.
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Retain accounting data by default for compliance unless specifically configured to drop.
// Note: To preserve financial ledger data and tax audit records, tables are preserved on standard deactivation.
