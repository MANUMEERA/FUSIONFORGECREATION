<?php
/**
 * Party Ledger Engine
 */

class FFC_Ledger {

    /**
     * Generates Party Ledger for a Client (Buyer)
     */
    public static function get_client_ledger($client_id, $from_date = null, $to_date = null) {
        global $wpdb;

        $table_clients = FFC_DB::get_table('clients');
        $client = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_clients WHERE id = %s", $client_id), ARRAY_A);
        if (!$client) {
            return new WP_Error('not_found', 'Client not found');
        }

        $opening_balance = floatval($client['opening_balance'] ?? 0);
        $entries = [];

        // 1. Fetch Invoices (Debits to Client)
        $table_inv = FFC_DB::get_table('invoices');
        $inv_sql = "SELECT id, invoice_number as doc_number, issue_date as doc_date, total_amount, 'Tax Invoice' as particular, 'invoice' as type FROM $table_inv WHERE client_id = %s";
        $invoices = $wpdb->get_results($wpdb->prepare($inv_sql, $client_id), ARRAY_A);

        foreach ($invoices as $inv) {
            $entries[] = [
                'date' => $inv['doc_date'],
                'particular' => 'Tax Invoice #' . $inv['doc_number'],
                'doc_type' => 'invoice',
                'doc_id' => $inv['id'],
                'doc_number' => $inv['doc_number'],
                'debit' => floatval($inv['total_amount']),
                'credit' => 0.00,
                'created_at' => $inv['doc_date']
            ];
        }

        // 2. Fetch Debit Notes (Debits to Client)
        $table_notes = FFC_DB::get_table('credit_debit_notes');
        $dbn_sql = "SELECT id, note_number as doc_number, note_date as doc_date, total_amount, reason, 'debit_note' as type FROM $table_notes WHERE party_id = %s AND note_type = 'debit_note'";
        $db_notes = $wpdb->get_results($wpdb->prepare($dbn_sql, $client_id), ARRAY_A);

        foreach ($db_notes as $n) {
            $entries[] = [
                'date' => $n['doc_date'],
                'particular' => 'Debit Note #' . $n['doc_number'] . ($n['reason'] ? ' (' . $n['reason'] . ')' : ''),
                'doc_type' => 'debit_note',
                'doc_id' => $n['id'],
                'doc_number' => $n['doc_number'],
                'debit' => floatval($n['total_amount']),
                'credit' => 0.00,
                'created_at' => $n['doc_date']
            ];
        }

        // 3. Fetch Credit Notes (Credits to Client)
        $crn_sql = "SELECT id, note_number as doc_number, note_date as doc_date, total_amount, reason, 'credit_note' as type FROM $table_notes WHERE party_id = %s AND note_type = 'credit_note'";
        $cr_notes = $wpdb->get_results($wpdb->prepare($crn_sql, $client_id), ARRAY_A);

        foreach ($cr_notes as $n) {
            $entries[] = [
                'date' => $n['doc_date'],
                'particular' => 'Credit Note #' . $n['doc_number'] . ($n['reason'] ? ' (' . $n['reason'] . ')' : ''),
                'doc_type' => 'credit_note',
                'doc_id' => $n['id'],
                'doc_number' => $n['doc_number'],
                'debit' => 0.00,
                'credit' => floatval($n['total_amount']),
                'created_at' => $n['doc_date']
            ];
        }

        // 4. Fetch Payments Received (Credits to Client)
        $table_pay = FFC_DB::get_table('payments');
        $pay_sql = "SELECT id, receipt_number as doc_number, payment_date as doc_date, amount, payment_mode, transaction_ref FROM $table_pay WHERE client_id = %s";
        $payments = $wpdb->get_results($wpdb->prepare($pay_sql, $client_id), ARRAY_A);

        foreach ($payments as $p) {
            $entries[] = [
                'date' => $p['doc_date'],
                'particular' => 'Payment Receipt #' . $p['doc_number'] . ($p['payment_mode'] ? ' via ' . $p['payment_mode'] : '') . ($p['transaction_ref'] ? ' (Ref: ' . $p['transaction_ref'] . ')' : ''),
                'doc_type' => 'payment_receipt',
                'doc_id' => $p['id'],
                'doc_number' => $p['doc_number'],
                'debit' => 0.00,
                'credit' => floatval($p['amount']),
                'created_at' => $p['doc_date']
            ];
        }

        // Sort entries chronologically
        usort($entries, function($a, $b) {
            return strcmp($a['date'], $b['date']);
        });

        // Compute running balance
        $running_balance = $opening_balance;
        $processed_entries = [];

        foreach ($entries as $e) {
            $running_balance += ($e['debit'] - $e['credit']);
            $e['running_balance'] = round($running_balance, 2);

            // Filter date range if specified
            if ($from_date && $e['date'] < $from_date) continue;
            if ($to_date && $e['date'] > $to_date) continue;

            $processed_entries[] = $e;
        }

        $total_debits = array_sum(array_column($processed_entries, 'debit'));
        $total_credits = array_sum(array_column($processed_entries, 'credit'));

        return [
            'client' => $client,
            'opening_balance' => $opening_balance,
            'entries' => $processed_entries,
            'total_debits' => round($total_debits, 2),
            'total_credits' => round($total_credits, 2),
            'closing_balance' => round($running_balance, 2),
            'currency' => 'INR'
        ];
    }
}
