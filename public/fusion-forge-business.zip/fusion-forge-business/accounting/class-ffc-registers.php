<?php
/**
 * Accounting Registers Class
 */

class FFC_Registers {

    /**
     * Sales Register with Invoices, Credit Notes & Debit Notes net calculations
     */
    public static function get_sales_register($filters = []) {
        global $wpdb;

        $table_inv = FFC_DB::get_table('invoices');
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['from_date'])) {
            $where[] = "issue_date >= %s";
            $params[] = $filters['from_date'];
        }
        if (!empty($filters['to_date'])) {
            $where[] = "issue_date <= %s";
            $params[] = $filters['to_date'];
        }
        if (!empty($filters['client_id'])) {
            $where[] = "client_id = %s";
            $params[] = $filters['client_id'];
        }
        if (!empty($filters['status'])) {
            $where[] = "status = %s";
            $params[] = $filters['status'];
        }

        $sql = "SELECT * FROM $table_inv WHERE " . implode(' AND ', $where) . " ORDER BY issue_date DESC";
        $invoices = !empty($params) ? $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);

        $total_taxable = 0.00;
        $total_cgst = 0.00;
        $total_sgst = 0.00;
        $total_utgst = 0.00;
        $total_igst = 0.00;
        $total_tax = 0.00;
        $total_amount = 0.00;
        $total_paid = 0.00;
        $total_balance = 0.00;

        foreach ($invoices as &$inv) {
            $total_taxable += floatval($inv['taxable_amount']);
            $total_cgst += floatval($inv['cgst_amount']);
            $total_sgst += floatval($inv['sgst_amount']);
            $total_utgst += floatval($inv['utgst_amount']);
            $total_igst += floatval($inv['igst_amount']);
            $total_tax += floatval($inv['total_tax']);
            $total_amount += floatval($inv['total_amount']);
            $total_paid += floatval($inv['amount_paid']);
            $total_balance += floatval($inv['balance_due']);
        }

        return [
            'rows' => $invoices,
            'summary' => [
                'count' => count($invoices),
                'total_taxable' => round($total_taxable, 2),
                'total_cgst' => round($total_cgst, 2),
                'total_sgst' => round($total_sgst, 2),
                'total_utgst' => round($total_utgst, 2),
                'total_igst' => round($total_igst, 2),
                'total_tax' => round($total_tax, 2),
                'total_amount' => round($total_amount, 2),
                'total_paid' => round($total_paid, 2),
                'total_balance' => round($total_balance, 2)
            ]
        ];
    }

    /**
     * Purchase Register
     */
    public static function get_purchase_register($filters = []) {
        global $wpdb;

        $table = FFC_DB::get_table('purchases');
        $where = ["1=1"];
        $params = [];

        if (!empty($filters['from_date'])) {
            $where[] = "bill_date >= %s";
            $params[] = $filters['from_date'];
        }
        if (!empty($filters['to_date'])) {
            $where[] = "bill_date <= %s";
            $params[] = $filters['to_date'];
        }
        if (!empty($filters['supplier_id'])) {
            $where[] = "supplier_id = %s";
            $params[] = $filters['supplier_id'];
        }

        $sql = "SELECT * FROM $table WHERE " . implode(' AND ', $where) . " ORDER BY bill_date DESC";
        $bills = !empty($params) ? $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A) : $wpdb->get_results($sql, ARRAY_A);

        $total_taxable = 0.00;
        $total_tax = 0.00;
        $total_amount = 0.00;

        foreach ($bills as $b) {
            $total_taxable += floatval($b['taxable_amount']);
            $total_tax += floatval($b['total_tax']);
            $total_amount += floatval($b['total_amount']);
        }

        return [
            'rows' => $bills,
            'summary' => [
                'count' => count($bills),
                'total_taxable' => round($total_taxable, 2),
                'total_tax' => round($total_tax, 2),
                'total_amount' => round($total_amount, 2)
            ]
        ];
    }

    /**
     * Credit / Debit Note Registers
     */
    public static function get_notes_register($note_type = 'credit_note', $filters = []) {
        global $wpdb;

        $table = FFC_DB::get_table('credit_debit_notes');
        $where = ["note_type = %s"];
        $params = [$note_type];

        if (!empty($filters['from_date'])) {
            $where[] = "note_date >= %s";
            $params[] = $filters['from_date'];
        }
        if (!empty($filters['to_date'])) {
            $where[] = "note_date <= %s";
            $params[] = $filters['to_date'];
        }

        $sql = "SELECT * FROM $table WHERE " . implode(' AND ', $where) . " ORDER BY note_date DESC";
        $notes = $wpdb->get_results($wpdb->prepare($sql, ...$params), ARRAY_A);

        $total_taxable = 0.00;
        $total_tax = 0.00;
        $total_amount = 0.00;

        foreach ($notes as $n) {
            $total_taxable += floatval($n['taxable_amount']);
            $total_tax += floatval($n['total_tax']);
            $total_amount += floatval($n['total_amount']);
        }

        return [
            'rows' => $notes,
            'summary' => [
                'count' => count($notes),
                'total_taxable' => round($total_taxable, 2),
                'total_tax' => round($total_tax, 2),
                'total_amount' => round($total_amount, 2)
            ]
        ];
    }
}
