<?php
/**
 * GST Calculation Engine for Indian Tax Compliance
 */

class FFC_GST_Engine {

    // Union Territories without Legislature that use UTGST
    private static $ut_state_codes = ['26', '31', '34', '35', '38']; 
    // 26: Dadra and Nagar Haveli and Daman and Diu, 31: Lakshadweep, 34: Chandigarh, 35: Andaman and Nicobar Islands, 38: Ladakh

    /**
     * Determines whether transaction is intra-state or inter-state
     */
    public static function is_intra_state($seller_state_code, $buyer_state_code, $place_of_supply = null) {
        $effective_buyer_code = $buyer_state_code;
        
        if (!empty($place_of_supply)) {
            // Check if place of supply contains digits
            if (preg_match('/^(\d{2})/', trim($place_of_supply), $matches)) {
                $effective_buyer_code = $matches[1];
            }
        }

        if (empty($seller_state_code) || empty($effective_buyer_code)) {
            return true; // default intra-state
        }

        return trim($seller_state_code) === trim($effective_buyer_code);
    }

    /**
     * Calculates GST breakdown for line items
     */
    public static function calculate_tax($taxable_amount, $gst_rate, $seller_state_code, $buyer_state_code, $place_of_supply = null) {
        $taxable_amount = floatval($taxable_amount);
        $gst_rate = floatval($gst_rate);

        $is_intra = self::is_intra_state($seller_state_code, $buyer_state_code, $place_of_supply);
        $is_ut = in_array(trim($seller_state_code), self::$ut_state_codes);

        $total_tax = round(($taxable_amount * $gst_rate) / 100, 2);

        $cgst = 0.00;
        $sgst = 0.00;
        $utgst = 0.00;
        $igst = 0.00;

        if ($is_intra) {
            $half_rate = $gst_rate / 2;
            $half_tax = round(($taxable_amount * $half_rate) / 100, 2);
            $cgst = $half_tax;

            if ($is_ut) {
                $utgst = $half_tax;
            } else {
                $sgst = $half_tax;
            }
            $total_tax = $cgst + ($is_ut ? $utgst : $sgst);
        } else {
            $igst = $total_tax;
        }

        return [
            'is_intra_state' => $is_intra,
            'is_utgst' => $is_ut && $is_intra,
            'taxable_amount' => $taxable_amount,
            'gst_rate' => $gst_rate,
            'cgst_amount' => $cgst,
            'sgst_amount' => $sgst,
            'utgst_amount' => $utgst,
            'igst_amount' => $igst,
            'total_tax' => $total_tax,
            'total_amount' => round($taxable_amount + $total_tax, 2)
        ];
    }
}
