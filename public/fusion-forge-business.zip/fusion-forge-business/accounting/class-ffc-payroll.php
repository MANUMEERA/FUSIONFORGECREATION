<?php
/**
 * Staff Attendance & Full Payroll Engine
 */

class FFC_Payroll {

    /**
     * Compute monthly salary record for a staff member based on master salary & attendance
     */
    public static function calculate_salary($staff_id, $month, $year, $overrides = []) {
        global $wpdb;

        $table_staff = FFC_DB::get_table('staff');
        $staff = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_staff WHERE id = %s", $staff_id), ARRAY_A);
        if (!$staff) {
            return new WP_Error('not_found', 'Staff member not found');
        }

        $base = floatval($overrides['base_salary'] ?? $staff['base_salary']);
        $hra = floatval($overrides['hra'] ?? $staff['hra']);
        $special = floatval($overrides['special_allowance'] ?? $staff['special_allowance']);
        $bonus = floatval($overrides['bonus'] ?? 0.00);

        // Fetch attendance days in month
        $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $table_att = FFC_DB::get_table('attendance');
        $from_date = sprintf('%04d-%02d-01', $year, $month);
        $to_date = sprintf('%04d-%02d-%02d', $year, $month, $days_in_month);

        $att_records = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as cnt FROM $table_att WHERE staff_id = %s AND attendance_date BETWEEN %s AND %s GROUP BY status",
            $staff_id, $from_date, $to_date
        ), ARRAY_A);

        $att_counts = [];
        foreach ($att_records as $r) {
            $att_counts[$r['status']] = intval($r['cnt']);
        }

        $absent_days = $att_counts['absent'] ?? 0;
        $half_days = $att_counts['half_day'] ?? 0;
        $effective_loss_of_pay_days = $absent_days + ($half_days * 0.5);

        // Calculate Gross Salary
        $monthly_fixed = $base + $hra + $special;
        $per_day_rate = $days_in_month > 0 ? ($monthly_fixed / $days_in_month) : 0;
        $lop_deduction = round($effective_loss_of_pay_days * $per_day_rate, 2);

        $gross_salary = round(max(0, $monthly_fixed - $lop_deduction) + $bonus, 2);

        // Deductions
        $pf = 0.00;
        if (!empty($staff['pf_applicable'])) {
            $pf = round(($base * 12) / 100, 2); // 12% of basic
        }

        $esi = 0.00;
        if (!empty($staff['esi_applicable']) && $gross_salary <= 21000) {
            $esi = round(($gross_salary * 0.75) / 100, 2); // 0.75% of gross
        }

        $pt = floatval($overrides['pt_deduction'] ?? 200.00); // Standard PT
        $tds = floatval($overrides['tds_deduction'] ?? 0.00);
        $advance = floatval($overrides['advance_deduction'] ?? 0.00);
        $other = floatval($overrides['other_deductions'] ?? 0.00);

        $total_deductions = round($pf + $esi + $pt + $tds + $advance + $other, 2);
        $net_salary = round(max(0, $gross_salary - $total_deductions), 2);

        return [
            'staff' => $staff,
            'month' => intval($month),
            'year' => intval($year),
            'days_in_month' => $days_in_month,
            'attendance_summary' => $att_counts,
            'lop_days' => $effective_loss_of_pay_days,
            'lop_deduction' => $lop_deduction,
            'base_salary' => $base,
            'hra' => $hra,
            'special_allowance' => $special,
            'bonus' => $bonus,
            'gross_salary' => $gross_salary,
            'pf_deduction' => $pf,
            'esi_deduction' => $esi,
            'pt_deduction' => $pt,
            'tds_deduction' => $tds,
            'advance_deduction' => $advance,
            'other_deductions' => $other,
            'total_deductions' => $total_deductions,
            'net_salary' => $net_salary
        ];
    }
}
