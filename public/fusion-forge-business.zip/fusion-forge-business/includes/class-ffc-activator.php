<?php
/**
 * Fired during plugin activation
 */

class FFC_Activator {

    public static function activate() {
        global $wpdb;

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        $charset_collate = $wpdb->get_charset_collate();

        // 1. Roles & Permissions Table
        $table_roles = $wpdb->prefix . 'ffc_roles';
        $sql_roles = "CREATE TABLE $table_roles (
            id varchar(64) NOT NULL,
            name varchar(100) NOT NULL,
            description text,
            permissions longtext NOT NULL,
            is_system tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_roles);

        // 2. User Profiles & 2FA Table
        $table_users = $wpdb->prefix . 'ffc_users';
        $sql_users = "CREATE TABLE $table_users (
            id varchar(64) NOT NULL,
            wp_user_id bigint(20) unsigned DEFAULT NULL,
            email varchar(191) NOT NULL,
            password_hash varchar(255) NOT NULL,
            name varchar(150) NOT NULL,
            role varchar(64) NOT NULL DEFAULT 'staff',
            custom_permissions longtext,
            totp_secret varchar(128) DEFAULT NULL,
            totp_enabled tinyint(1) DEFAULT 0,
            status varchar(32) DEFAULT 'active',
            avatar_url text,
            last_login datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY email (email)
        ) $charset_collate;";
        dbDelta($sql_users);

        // 3. Seller / Company Master Profile
        $table_seller = $wpdb->prefix . 'ffc_seller_profile';
        $sql_seller = "CREATE TABLE $table_seller (
            id varchar(64) NOT NULL DEFAULT 'default_seller',
            company_name varchar(255) NOT NULL,
            legal_name varchar(255) DEFAULT NULL,
            tagline varchar(255) DEFAULT NULL,
            motto varchar(255) DEFAULT NULL,
            email varchar(191) NOT NULL,
            phone varchar(64) NOT NULL,
            website varchar(255) DEFAULT NULL,
            address text NOT NULL,
            city varchar(100) DEFAULT NULL,
            state varchar(100) DEFAULT NULL,
            state_code varchar(10) DEFAULT NULL,
            postal_code varchar(20) DEFAULT NULL,
            gstin varchar(30) DEFAULT NULL,
            pan varchar(20) DEFAULT NULL,
            msme_reg varchar(64) DEFAULT NULL,
            lut_number varchar(64) DEFAULT NULL,
            lut_expiry date DEFAULT NULL,
            sac_code varchar(20) DEFAULT '998314',
            bank_name varchar(150) DEFAULT NULL,
            account_name varchar(200) DEFAULT NULL,
            account_number varchar(64) DEFAULT NULL,
            ifsc varchar(30) DEFAULT NULL,
            branch varchar(150) DEFAULT NULL,
            upi_id varchar(150) DEFAULT NULL,
            qr_string text DEFAULT NULL,
            logo_url longtext DEFAULT NULL,
            signature_url longtext DEFAULT NULL,
            stamp_url longtext DEFAULT NULL,
            quotation_terms longtext DEFAULT NULL,
            invoice_terms longtext DEFAULT NULL,
            default_validity_days int DEFAULT 30,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_seller);

        // 4. Clients / Buyer Master
        $table_clients = $wpdb->prefix . 'ffc_clients';
        $sql_clients = "CREATE TABLE $table_clients (
            id varchar(64) NOT NULL,
            client_code varchar(64) DEFAULT NULL,
            name varchar(150) NOT NULL,
            company varchar(200) DEFAULT NULL,
            email varchar(191) DEFAULT NULL,
            phone varchar(64) DEFAULT NULL,
            billing_address text DEFAULT NULL,
            shipping_address text DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            state varchar(100) DEFAULT NULL,
            state_code varchar(10) DEFAULT NULL,
            pincode varchar(20) DEFAULT NULL,
            gstin varchar(30) DEFAULT NULL,
            pan varchar(20) DEFAULT NULL,
            place_of_supply varchar(100) DEFAULT NULL,
            payment_terms varchar(100) DEFAULT '100% Advance',
            credit_limit decimal(15,2) DEFAULT 0.00,
            opening_balance decimal(15,2) DEFAULT 0.00,
            status varchar(32) DEFAULT 'active',
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_clients);

        // 5. Suppliers Master
        $table_suppliers = $wpdb->prefix . 'ffc_suppliers';
        $sql_suppliers = "CREATE TABLE $table_suppliers (
            id varchar(64) NOT NULL,
            supplier_code varchar(64) DEFAULT NULL,
            name varchar(150) NOT NULL,
            company_name varchar(200) DEFAULT NULL,
            email varchar(191) DEFAULT NULL,
            phone varchar(64) DEFAULT NULL,
            address text DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            state varchar(100) DEFAULT NULL,
            state_code varchar(10) DEFAULT NULL,
            pincode varchar(20) DEFAULT NULL,
            gstin varchar(30) DEFAULT NULL,
            pan varchar(20) DEFAULT NULL,
            opening_balance decimal(15,2) DEFAULT 0.00,
            payment_terms varchar(100) DEFAULT 'Net 30',
            status varchar(32) DEFAULT 'active',
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_suppliers);

        // 6. Unit of Measurement (UOM/UQC) Master
        $table_units = $wpdb->prefix . 'ffc_units';
        $sql_units = "CREATE TABLE $table_units (
            id varchar(32) NOT NULL,
            name varchar(100) NOT NULL,
            symbol varchar(20) NOT NULL,
            is_decimal tinyint(1) DEFAULT 0,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_units);

        // 7. HSN / SAC Master
        $table_hsn = $wpdb->prefix . 'ffc_hsn_master';
        $sql_hsn = "CREATE TABLE $table_hsn (
            id varchar(64) NOT NULL,
            code varchar(30) NOT NULL,
            type varchar(20) DEFAULT 'SAC',
            description text NOT NULL,
            gst_rate decimal(5,2) NOT NULL DEFAULT 18.00,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_hsn);

        // 8. Goods & Items Catalog Master
        $table_goods = $wpdb->prefix . 'ffc_goods_items';
        $sql_goods = "CREATE TABLE $table_goods (
            id varchar(64) NOT NULL,
            item_code varchar(64) DEFAULT NULL,
            name varchar(200) NOT NULL,
            description text DEFAULT NULL,
            type varchar(32) DEFAULT 'service',
            hsn_sac_code varchar(30) DEFAULT '998314',
            unit varchar(32) DEFAULT 'NOS',
            sale_price decimal(15,2) DEFAULT 0.00,
            purchase_price decimal(15,2) DEFAULT 0.00,
            gst_rate decimal(5,2) DEFAULT 18.00,
            status varchar(32) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_goods);

        // 9. Document Numbering Configuration
        $table_numbering = $wpdb->prefix . 'ffc_document_numbering';
        $sql_numbering = "CREATE TABLE $table_numbering (
            id varchar(64) NOT NULL,
            doc_type varchar(64) NOT NULL,
            prefix varchar(32) NOT NULL,
            suffix varchar(32) DEFAULT '',
            padding_digits int NOT NULL DEFAULT 4,
            use_financial_year tinyint(1) DEFAULT 1,
            separator_char varchar(5) DEFAULT '/',
            current_sequence int NOT NULL DEFAULT 0,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY doc_type (doc_type)
        ) $charset_collate;";
        dbDelta($sql_numbering);

        // 10. Quotations & Scopes
        $table_quotations = $wpdb->prefix . 'ffc_quotations';
        $sql_quotations = "CREATE TABLE $table_quotations (
            id varchar(64) NOT NULL,
            quotation_number varchar(100) NOT NULL,
            client_id varchar(64) DEFAULT NULL,
            client_name varchar(150) NOT NULL,
            client_company varchar(200) DEFAULT NULL,
            client_email varchar(191) DEFAULT NULL,
            client_phone varchar(64) DEFAULT NULL,
            client_address text DEFAULT NULL,
            client_gstin varchar(30) DEFAULT NULL,
            place_of_supply varchar(100) DEFAULT NULL,
            subject varchar(255) NOT NULL,
            items longtext NOT NULL,
            subtotal decimal(15,2) NOT NULL DEFAULT 0.00,
            discount_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            taxable_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            cgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            sgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            utgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            igst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            total_tax decimal(15,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            payment_terms varchar(100) DEFAULT '100% Advance',
            validity_days int DEFAULT 30,
            status varchar(32) DEFAULT 'draft',
            terms text DEFAULT NULL,
            notes text DEFAULT NULL,
            converted_invoice_id varchar(64) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY quotation_number (quotation_number)
        ) $charset_collate;";
        dbDelta($sql_quotations);

        // 11. Tax Invoices
        $table_invoices = $wpdb->prefix . 'ffc_invoices';
        $sql_invoices = "CREATE TABLE $table_invoices (
            id varchar(64) NOT NULL,
            invoice_number varchar(100) NOT NULL,
            quotation_id varchar(64) DEFAULT NULL,
            client_id varchar(64) DEFAULT NULL,
            client_name varchar(150) NOT NULL,
            client_company varchar(200) DEFAULT NULL,
            client_email varchar(191) DEFAULT NULL,
            client_phone varchar(64) DEFAULT NULL,
            client_address text DEFAULT NULL,
            client_gstin varchar(30) DEFAULT NULL,
            place_of_supply varchar(100) DEFAULT NULL,
            issue_date date NOT NULL,
            due_date date DEFAULT NULL,
            items longtext NOT NULL,
            subtotal decimal(15,2) NOT NULL DEFAULT 0.00,
            discount_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            taxable_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            cgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            sgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            utgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            igst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            total_tax decimal(15,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            amount_paid decimal(15,2) NOT NULL DEFAULT 0.00,
            balance_due decimal(15,2) NOT NULL DEFAULT 0.00,
            status varchar(32) DEFAULT 'unpaid',
            reverse_charge tinyint(1) DEFAULT 0,
            irn varchar(128) DEFAULT NULL,
            ack_no varchar(64) DEFAULT NULL,
            ack_date datetime DEFAULT NULL,
            qr_data text DEFAULT NULL,
            notes text DEFAULT NULL,
            terms text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY invoice_number (invoice_number)
        ) $charset_collate;";
        dbDelta($sql_invoices);

        // 12. Payment Receipts
        $table_payments = $wpdb->prefix . 'ffc_payments';
        $sql_payments = "CREATE TABLE $table_payments (
            id varchar(64) NOT NULL,
            receipt_number varchar(100) NOT NULL,
            invoice_id varchar(64) DEFAULT NULL,
            invoice_number varchar(100) DEFAULT NULL,
            client_id varchar(64) DEFAULT NULL,
            client_name varchar(150) NOT NULL,
            client_company varchar(200) DEFAULT NULL,
            amount decimal(15,2) NOT NULL DEFAULT 0.00,
            payment_date date NOT NULL,
            payment_mode varchar(50) DEFAULT 'Bank Transfer',
            transaction_ref varchar(100) DEFAULT NULL,
            bank_account varchar(100) DEFAULT NULL,
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY receipt_number (receipt_number)
        ) $charset_collate;";
        dbDelta($sql_payments);

        // 13. Credit & Debit Notes
        $table_notes = $wpdb->prefix . 'ffc_credit_debit_notes';
        $sql_notes = "CREATE TABLE $table_notes (
            id varchar(64) NOT NULL,
            note_number varchar(100) NOT NULL,
            note_type varchar(20) NOT NULL, -- 'credit_note' or 'debit_note'
            party_type varchar(20) NOT NULL DEFAULT 'client', -- 'client' or 'supplier'
            party_id varchar(64) DEFAULT NULL,
            party_name varchar(150) NOT NULL,
            party_gstin varchar(30) DEFAULT NULL,
            reference_doc_type varchar(50) DEFAULT 'invoice',
            reference_doc_number varchar(100) DEFAULT NULL,
            reference_doc_date date DEFAULT NULL,
            note_date date NOT NULL,
            reason varchar(255) NOT NULL,
            items longtext NOT NULL,
            taxable_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            cgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            sgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            utgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            igst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            total_tax decimal(15,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            status varchar(32) DEFAULT 'issued',
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY note_number (note_number)
        ) $charset_collate;";
        dbDelta($sql_notes);

        // 14. Purchase Orders & Purchases (Bills)
        $table_purchases = $wpdb->prefix . 'ffc_purchases';
        $sql_purchases = "CREATE TABLE $table_purchases (
            id varchar(64) NOT NULL,
            doc_type varchar(32) NOT NULL DEFAULT 'bill', -- 'purchase_order' or 'bill'
            doc_number varchar(100) NOT NULL,
            supplier_id varchar(64) DEFAULT NULL,
            supplier_name varchar(150) NOT NULL,
            supplier_company varchar(200) DEFAULT NULL,
            supplier_gstin varchar(30) DEFAULT NULL,
            bill_date date NOT NULL,
            due_date date DEFAULT NULL,
            items longtext NOT NULL,
            taxable_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            cgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            sgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            utgst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            igst_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            total_tax decimal(15,2) NOT NULL DEFAULT 0.00,
            total_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            amount_paid decimal(15,2) NOT NULL DEFAULT 0.00,
            payment_status varchar(32) DEFAULT 'unpaid',
            itc_eligible tinyint(1) DEFAULT 1,
            reverse_charge tinyint(1) DEFAULT 0,
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY doc_number (doc_number)
        ) $charset_collate;";
        dbDelta($sql_purchases);

        // 15. Operating Expenses
        $table_expenses = $wpdb->prefix . 'ffc_expenses';
        $sql_expenses = "CREATE TABLE $table_expenses (
            id varchar(64) NOT NULL,
            expense_code varchar(64) DEFAULT NULL,
            category varchar(100) NOT NULL,
            title varchar(200) NOT NULL,
            amount decimal(15,2) NOT NULL DEFAULT 0.00,
            tax_amount decimal(15,2) NOT NULL DEFAULT 0.00,
            expense_date date NOT NULL,
            paid_to varchar(150) DEFAULT NULL,
            payment_mode varchar(50) DEFAULT 'Bank Transfer',
            receipt_url text DEFAULT NULL,
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_expenses);

        // 16. Staff Master
        $table_staff = $wpdb->prefix . 'ffc_staff';
        $sql_staff = "CREATE TABLE $table_staff (
            id varchar(64) NOT NULL,
            employee_code varchar(64) NOT NULL,
            name varchar(150) NOT NULL,
            email varchar(191) DEFAULT NULL,
            phone varchar(64) DEFAULT NULL,
            designation varchar(100) NOT NULL,
            department varchar(100) DEFAULT 'Engineering',
            joining_date date NOT NULL,
            pan varchar(20) DEFAULT NULL,
            bank_account_name varchar(150) DEFAULT NULL,
            bank_name varchar(150) DEFAULT NULL,
            account_number varchar(64) DEFAULT NULL,
            ifsc varchar(30) DEFAULT NULL,
            base_salary decimal(15,2) NOT NULL DEFAULT 0.00,
            hra decimal(15,2) DEFAULT 0.00,
            special_allowance decimal(15,2) DEFAULT 0.00,
            pf_applicable tinyint(1) DEFAULT 0,
            esi_applicable tinyint(1) DEFAULT 0,
            tds_applicable tinyint(1) DEFAULT 0,
            status varchar(32) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY employee_code (employee_code)
        ) $charset_collate;";
        dbDelta($sql_staff);

        // 17. Staff Daily Attendance
        $table_attendance = $wpdb->prefix . 'ffc_attendance';
        $sql_attendance = "CREATE TABLE $table_attendance (
            id varchar(64) NOT NULL,
            staff_id varchar(64) NOT NULL,
            attendance_date date NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'present', -- 'present','absent','half_day','leave','holiday','weekly_off'
            check_in time DEFAULT NULL,
            check_out time DEFAULT NULL,
            remarks text DEFAULT NULL,
            updated_by varchar(64) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY staff_date (staff_id, attendance_date)
        ) $charset_collate;";
        dbDelta($sql_attendance);

        // 18. Full Monthly Payroll & Payslips
        $table_payroll = $wpdb->prefix . 'ffc_salary_records';
        $sql_payroll = "CREATE TABLE $table_payroll (
            id varchar(64) NOT NULL,
            payslip_number varchar(100) NOT NULL,
            staff_id varchar(64) NOT NULL,
            month int NOT NULL,
            year int NOT NULL,
            base_salary decimal(15,2) NOT NULL DEFAULT 0.00,
            hra decimal(15,2) DEFAULT 0.00,
            special_allowance decimal(15,2) DEFAULT 0.00,
            bonus decimal(15,2) DEFAULT 0.00,
            gross_salary decimal(15,2) NOT NULL DEFAULT 0.00,
            pf_deduction decimal(15,2) DEFAULT 0.00,
            esi_deduction decimal(15,2) DEFAULT 0.00,
            pt_deduction decimal(15,2) DEFAULT 0.00,
            tds_deduction decimal(15,2) DEFAULT 0.00,
            advance_deduction decimal(15,2) DEFAULT 0.00,
            other_deductions decimal(15,2) DEFAULT 0.00,
            total_deductions decimal(15,2) NOT NULL DEFAULT 0.00,
            net_salary decimal(15,2) NOT NULL DEFAULT 0.00,
            payment_date date DEFAULT NULL,
            payment_mode varchar(50) DEFAULT 'Bank Transfer',
            transaction_ref varchar(100) DEFAULT NULL,
            status varchar(32) DEFAULT 'draft',
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY payslip_number (payslip_number),
            UNIQUE KEY staff_month_year (staff_id, month, year)
        ) $charset_collate;";
        dbDelta($sql_payroll);

        // 19. Lead Enquiries Table
        $table_enquiries = $wpdb->prefix . 'ffc_enquiries';
        $sql_enquiries = "CREATE TABLE $table_enquiries (
            id varchar(64) NOT NULL,
            name varchar(150) NOT NULL,
            email varchar(191) NOT NULL,
            phone varchar(64) DEFAULT NULL,
            company varchar(200) DEFAULT NULL,
            service varchar(100) DEFAULT NULL,
            budget varchar(100) DEFAULT NULL,
            message text NOT NULL,
            source varchar(100) DEFAULT 'website',
            status varchar(32) DEFAULT 'new',
            notes text DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_enquiries);

        // 20. Audit Trail Logs
        $table_audit = $wpdb->prefix . 'ffc_audit_logs';
        $sql_audit = "CREATE TABLE $table_audit (
            id varchar(64) NOT NULL,
            user_id varchar(64) DEFAULT NULL,
            user_email varchar(191) DEFAULT NULL,
            action varchar(100) NOT NULL,
            module varchar(64) NOT NULL,
            entity_id varchar(64) DEFAULT NULL,
            details text DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        dbDelta($sql_audit);

        // Seed Default Initial Records
        self::seed_defaults();
    }

    private static function seed_defaults() {
        global $wpdb;

        // Seed Seller Profile
        $table_seller = $wpdb->prefix . 'ffc_seller_profile';
        $existing_seller = $wpdb->get_var("SELECT COUNT(*) FROM $table_seller");
        if (!$existing_seller) {
            $wpdb->insert($table_seller, [
                'id' => 'default_seller',
                'company_name' => 'Fusion Forge Creations',
                'legal_name' => 'Fusion Forge Creations',
                'tagline' => 'Where Ideas Fuse With Technology',
                'motto' => 'INNOVATE • BUILD • AUTOMATE • GROW',
                'email' => 'admin@fusionforgecreation.com',
                'phone' => '+91 9033008720',
                'website' => 'https://fusionforgecreation.com',
                'address' => 'Flat No H2/203, Yogi Milan, Near Ring Road, Amli, Silvassa, Dadra & Nagar Haveli - 396230',
                'city' => 'Silvassa',
                'state' => 'Dadra & Nagar Haveli and Daman & Diu',
                'state_code' => '26',
                'postal_code' => '396230',
                'gstin' => '', // Kept blank until provided
                'pan' => '',
                'sac_code' => '998314',
                'bank_name' => 'State Bank of India',
                'account_name' => 'Fusion Forge Creations',
                'account_number' => '',
                'ifsc' => '',
                'branch' => 'Silvassa Main',
                'upi_id' => 'admin@fusionforgecreation',
                'quotation_terms' => "1. 50% advance along with confirmed work order.\n2. Balance 50% upon milestone completion and deployment sign-off.\n3. Taxes as applicable under Indian GST laws.\n4. Scope changes will be billed under standard hourly/sprint rates.",
                'invoice_terms' => "1. Payment is due within standard invoice terms.\n2. Please mention Invoice Number in bank transfer remark.\n3. Subject to Silvassa jurisdiction.",
                'default_validity_days' => 30
            ]);
        }

        // Seed Document Numbering
        $table_num = $wpdb->prefix . 'ffc_document_numbering';
        $existing_num = $wpdb->get_var("SELECT COUNT(*) FROM $table_num");
        if (!$existing_num) {
            $defaults = [
                ['id' => 'num_quotation', 'doc_type' => 'quotation', 'prefix' => 'FFC/QTN', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_invoice', 'doc_type' => 'invoice', 'prefix' => 'FFC/INV', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_receipt', 'doc_type' => 'payment_receipt', 'prefix' => 'FFC/RCT', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_po', 'doc_type' => 'purchase_order', 'prefix' => 'FFC/PO', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_credit_note', 'doc_type' => 'credit_note', 'prefix' => 'FFC/CRN', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_debit_note', 'doc_type' => 'debit_note', 'prefix' => 'FFC/DBN', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0],
                ['id' => 'num_payslip', 'doc_type' => 'payslip', 'prefix' => 'FFC/PAY', 'padding_digits' => 4, 'use_financial_year' => 1, 'current_sequence' => 0]
            ];
            foreach ($defaults as $d) {
                $wpdb->insert($table_num, $d);
            }
        }

        // Seed Units
        $table_units = $wpdb->prefix . 'ffc_units';
        if (!$wpdb->get_var("SELECT COUNT(*) FROM $table_units")) {
            $units = [
                ['id' => 'NOS', 'name' => 'Numbers', 'symbol' => 'NOS', 'is_decimal' => 0],
                ['id' => 'HRS', 'name' => 'Hours', 'symbol' => 'HRS', 'is_decimal' => 1],
                ['id' => 'DAYS', 'name' => 'Days', 'symbol' => 'DAYS', 'is_decimal' => 0],
                ['id' => 'MTH', 'name' => 'Months', 'symbol' => 'MTH', 'is_decimal' => 0],
                ['id' => 'SET', 'name' => 'Sets', 'symbol' => 'SET', 'is_decimal' => 0],
                ['id' => 'PROJECT', 'name' => 'Project', 'symbol' => 'PRJ', 'is_decimal' => 0]
            ];
            foreach ($units as $u) {
                $wpdb->insert($table_units, $u);
            }
        }

        // Seed HSN / SAC Codes
        $table_hsn = $wpdb->prefix . 'ffc_hsn_master';
        if (!$wpdb->get_var("SELECT COUNT(*) FROM $table_hsn")) {
            $hsn_codes = [
                ['id' => 'hsn_998314', 'code' => '998314', 'type' => 'SAC', 'description' => 'Information technology and software development services', 'gst_rate' => 18.00],
                ['id' => 'hsn_998313', 'code' => '998313', 'type' => 'SAC', 'description' => 'Information technology consulting and support services', 'gst_rate' => 18.00],
                ['id' => 'hsn_998315', 'code' => '998315', 'type' => 'SAC', 'description' => 'Hosting, cloud infrastructure and data processing services', 'gst_rate' => 18.00],
                ['id' => 'hsn_998311', 'code' => '998311', 'type' => 'SAC', 'description' => 'Management consulting and technical advisory services', 'gst_rate' => 18.00]
            ];
            foreach ($hsn_codes as $h) {
                $wpdb->insert($table_hsn, $h);
            }
        }

        // Seed Roles & Permissions
        $table_roles = $wpdb->prefix . 'ffc_roles';
        if (!$wpdb->get_var("SELECT COUNT(*) FROM $table_roles")) {
            $all_perms = json_encode([
                'module.dashboard', 'module.enquiries', 'module.clients', 'module.quotations',
                'module.invoices', 'module.payments', 'module.purchases', 'module.expenses',
                'module.credit_notes', 'module.debit_notes', 'module.ledger', 'module.staff',
                'module.payroll', 'module.reports', 'module.users', 'module.settings',
                'op.view', 'op.create', 'op.edit', 'op.delete', 'op.export', 'op.print', 'op.send', 'op.approve'
            ]);

            $staff_perms = json_encode([
                'module.dashboard', 'module.enquiries', 'module.clients', 'module.quotations',
                'module.invoices', 'module.payments', 'module.purchases', 'module.expenses',
                'module.credit_notes', 'module.debit_notes', 'module.ledger', 'module.reports',
                'op.view', 'op.create', 'op.edit', 'op.export', 'op.print'
            ]);

            $wpdb->insert($table_roles, [
                'id' => 'super_admin',
                'name' => 'Super Administrator',
                'description' => 'Full unrestricted access to all ERP modules, settings, users and financial records.',
                'permissions' => $all_perms,
                'is_system' => 1
            ]);

            $wpdb->insert($table_roles, [
                'id' => 'admin',
                'name' => 'Administrator',
                'description' => 'Administrative management access to all operational and accounting modules.',
                'permissions' => $all_perms,
                'is_system' => 1
            ]);

            $wpdb->insert($table_roles, [
                'id' => 'staff',
                'name' => 'Staff / Accounts Officer',
                'description' => 'Standard accounting, quotation, invoice, and party ledger operations.',
                'permissions' => $staff_perms,
                'is_system' => 1
            ]);
        }
    }
}
