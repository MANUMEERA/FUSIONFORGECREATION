<?php
/**
 * Fired during plugin deactivation
 */

class FFC_Deactivator {
    public static function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
