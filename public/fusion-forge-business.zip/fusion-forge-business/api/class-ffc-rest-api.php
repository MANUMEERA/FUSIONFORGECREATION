<?php
/**
 * WordPress REST API Controller for Fusion Forge ERP
 */

class FFC_REST_API {

    const NAMESPACE = 'ffc/v1';

    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    public static function register_routes() {
        // 1. Auth routes
        register_rest_route(self::NAMESPACE, '/auth/login', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'handle_login'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route(self::NAMESPACE, '/auth/logout', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'handle_logout'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route(self::NAMESPACE, '/auth/me', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'handle_get_current_user'],
            'permission_callback' => '__return_true'
        ]);

        // 2. Seller Profile
        register_rest_route(self::NAMESPACE, '/seller-profile', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_seller_profile'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route(self::NAMESPACE, '/seller-profile', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'update_seller_profile'],
            'permission_callback' => [__CLASS__, 'check_admin_permission']
        ]);

        // 3. Clients & Party Ledger
        register_rest_route(self::NAMESPACE, '/clients', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_clients'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/clients', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_client'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/clients/(?P<id>[a-zA-Z0-9_-]+)/ledger', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_client_ledger'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 4. Quotations
        register_rest_route(self::NAMESPACE, '/quotations', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_quotations'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/quotations', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_quotation'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 5. Invoices
        register_rest_route(self::NAMESPACE, '/invoices', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_invoices'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/invoices', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_invoice'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 6. Payments
        register_rest_route(self::NAMESPACE, '/payments', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_payments'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/payments', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_payment'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 7. Credit & Debit Notes
        register_rest_route(self::NAMESPACE, '/notes', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_notes'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/notes', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_note'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 8. Purchases & Expenses
        register_rest_route(self::NAMESPACE, '/purchases', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_purchases'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/purchases', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_purchase'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/expenses', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_expenses'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/expenses', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'create_expense'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 9. Staff & Payroll
        register_rest_route(self::NAMESPACE, '/staff', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_staff'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/attendance', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_attendance'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/attendance', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'save_attendance'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/payroll', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_payroll'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/payroll/generate', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'generate_payroll'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 10. Registers & Reports
        register_rest_route(self::NAMESPACE, '/registers/sales', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_sales_register'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/registers/purchases', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_purchase_register'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        register_rest_route(self::NAMESPACE, '/reports/summary', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_financial_summary'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);

        // 11. Public Enquiry Submission
        register_rest_route(self::NAMESPACE, '/enquiries', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'submit_enquiry'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route(self::NAMESPACE, '/enquiries', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_enquiries'],
            'permission_callback' => [__CLASS__, 'check_auth_permission']
        ]);
    }

    public static function check_auth_permission() {
        $user = FFC_Auth::get_current_user();
        return !empty($user);
    }

    public static function check_admin_permission() {
        $user = FFC_Auth::get_current_user();
        return !empty($user) && in_array($user['role'], ['super_admin', 'admin']);
    }

    public static function handle_login($request) {
        $params = $request->get_json_params();
        $email = sanitize_email($params['email'] ?? '');
        $password = $params['password'] ?? '';
        $totp = sanitize_text_field($params['totp_code'] ?? '');

        $result = FFC_Auth::login($email, $password, $totp);
        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'message' => $result->get_error_message()], 401);
        }

        return new WP_REST_Response(['success' => true, 'data' => $result], 200);
    }

    public static function handle_logout() {
        FFC_Auth::logout();
        return new WP_REST_Response(['success' => true, 'message' => 'Logged out successfully.'], 200);
    }

    public static function handle_get_current_user() {
        $user = FFC_Auth::get_current_user();
        return new WP_REST_Response(['success' => true, 'user' => $user], 200);
    }

    public static function get_seller_profile() {
        $profile = FFC_DB::get_seller_profile();
        return new WP_REST_Response(['success' => true, 'data' => $profile], 200);
    }

    public static function update_seller_profile($request) {
        $data = $request->get_json_params();
        FFC_DB::update_seller_profile($data);
        return new WP_REST_Response(['success' => true, 'message' => 'Profile updated.'], 200);
    }

    public static function get_clients() {
        global $wpdb;
        $table = FFC_DB::get_table('clients');
        $clients = $wpdb->get_results("SELECT * FROM $table ORDER BY name ASC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $clients], 200);
    }

    public static function create_client($request) {
        global $wpdb;
        $table = FFC_DB::get_table('clients');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('client_' . uniqid());
        $params['id'] = $id;

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id], 200);
    }

    public static function get_client_ledger($request) {
        $id = $request->get_param('id');
        $from = $request->get_param('from_date');
        $to = $request->get_param('to_date');

        $ledger = FFC_Ledger::get_client_ledger($id, $from, $to);
        if (is_wp_error($ledger)) {
            return new WP_REST_Response(['success' => false, 'message' => $ledger->get_error_message()], 404);
        }

        return new WP_REST_Response(['success' => true, 'data' => $ledger], 200);
    }

    public static function get_quotations() {
        global $wpdb;
        $table = FFC_DB::get_table('quotations');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_quotation($request) {
        global $wpdb;
        $table = FFC_DB::get_table('quotations');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('qtn_' . uniqid());
        $params['id'] = $id;
        if (empty($params['quotation_number'])) {
            $params['quotation_number'] = FFC_Numbering::generate_next_number('quotation');
        }
        if (is_array($params['items'])) {
            $params['items'] = json_encode($params['items']);
        }

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id, 'quotation_number' => $params['quotation_number']], 200);
    }

    public static function get_invoices() {
        global $wpdb;
        $table = FFC_DB::get_table('invoices');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY issue_date DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_invoice($request) {
        global $wpdb;
        $table = FFC_DB::get_table('invoices');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('inv_' . uniqid());
        $params['id'] = $id;
        if (empty($params['invoice_number'])) {
            $params['invoice_number'] = FFC_Numbering::generate_next_number('invoice');
        }
        if (is_array($params['items'])) {
            $params['items'] = json_encode($params['items']);
        }

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id, 'invoice_number' => $params['invoice_number']], 200);
    }

    public static function get_payments() {
        global $wpdb;
        $table = FFC_DB::get_table('payments');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY payment_date DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_payment($request) {
        global $wpdb;
        $table = FFC_DB::get_table('payments');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('pay_' . uniqid());
        $params['id'] = $id;
        if (empty($params['receipt_number'])) {
            $params['receipt_number'] = FFC_Numbering::generate_next_number('payment_receipt');
        }

        $wpdb->insert($table, $params);

        // Update invoice amount_paid and balance_due if invoice_id is linked
        if (!empty($params['invoice_id'])) {
            $table_inv = FFC_DB::get_table('invoices');
            $inv = $wpdb->get_row($wpdb->prepare("SELECT total_amount, amount_paid FROM $table_inv WHERE id = %s", $params['invoice_id']), ARRAY_A);
            if ($inv) {
                $new_paid = floatval($inv['amount_paid']) + floatval($params['amount']);
                $new_bal = max(0, floatval($inv['total_amount']) - $new_paid);
                $status = $new_bal <= 0 ? 'paid' : ($new_paid > 0 ? 'partial' : 'unpaid');
                $wpdb->update($table_inv, [
                    'amount_paid' => $new_paid,
                    'balance_due' => $new_bal,
                    'status' => $status
                ], ['id' => $params['invoice_id']]);
            }
        }

        return new WP_REST_Response(['success' => true, 'id' => $id, 'receipt_number' => $params['receipt_number']], 200);
    }

    public static function get_notes() {
        global $wpdb;
        $table = FFC_DB::get_table('credit_debit_notes');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY note_date DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_note($request) {
        global $wpdb;
        $table = FFC_DB::get_table('credit_debit_notes');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('note_' . uniqid());
        $params['id'] = $id;
        $type = $params['note_type'] === 'debit_note' ? 'debit_note' : 'credit_note';
        if (empty($params['note_number'])) {
            $params['note_number'] = FFC_Numbering::generate_next_number($type);
        }
        if (is_array($params['items'])) {
            $params['items'] = json_encode($params['items']);
        }

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id, 'note_number' => $params['note_number']], 200);
    }

    public static function get_purchases() {
        global $wpdb;
        $table = FFC_DB::get_table('purchases');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY bill_date DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_purchase($request) {
        global $wpdb;
        $table = FFC_DB::get_table('purchases');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('pur_' . uniqid());
        $params['id'] = $id;
        if (is_array($params['items'])) {
            $params['items'] = json_encode($params['items']);
        }

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id], 200);
    }

    public static function get_expenses() {
        global $wpdb;
        $table = FFC_DB::get_table('expenses');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY expense_date DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function create_expense($request) {
        global $wpdb;
        $table = FFC_DB::get_table('expenses');
        $params = $request->get_json_params();

        $id = $params['id'] ?? ('exp_' . uniqid());
        $params['id'] = $id;

        $wpdb->insert($table, $params);
        return new WP_REST_Response(['success' => true, 'id' => $id], 200);
    }

    public static function get_staff() {
        global $wpdb;
        $table = FFC_DB::get_table('staff');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY name ASC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function get_attendance($request) {
        global $wpdb;
        $table = FFC_DB::get_table('attendance');
        $date = $request->get_param('date') ?: date('Y-m-d');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE attendance_date = %s", $date), ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function save_attendance($request) {
        global $wpdb;
        $table = FFC_DB::get_table('attendance');
        $params = $request->get_json_params();

        $staff_id = $params['staff_id'];
        $date = $params['attendance_date'];
        $status = $params['status'] ?? 'present';
        $remarks = $params['remarks'] ?? '';

        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE staff_id = %s AND attendance_date = %s", $staff_id, $date));
        if ($existing) {
            $wpdb->update($table, ['status' => $status, 'remarks' => $remarks], ['id' => $existing]);
        } else {
            $wpdb->insert($table, [
                'id' => 'att_' . uniqid(),
                'staff_id' => $staff_id,
                'attendance_date' => $date,
                'status' => $status,
                'remarks' => $remarks
            ]);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Attendance saved.'], 200);
    }

    public static function get_payroll() {
        global $wpdb;
        $table = FFC_DB::get_table('salary_records');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY year DESC, month DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }

    public static function generate_payroll($request) {
        global $wpdb;
        $params = $request->get_json_params();
        $staff_id = $params['staff_id'];
        $month = intval($params['month'] ?? date('n'));
        $year = intval($params['year'] ?? date('Y'));

        $calc = FFC_Payroll::calculate_salary($staff_id, $month, $year, $params);
        if (is_wp_error($calc)) {
            return new WP_REST_Response(['success' => false, 'message' => $calc->get_error_message()], 400);
        }

        $table = FFC_DB::get_table('salary_records');
        $payslip_number = FFC_Numbering::generate_next_number('payslip');

        $record_id = 'sal_' . uniqid();
        $wpdb->insert($table, [
            'id' => $record_id,
            'payslip_number' => $payslip_number,
            'staff_id' => $staff_id,
            'month' => $month,
            'year' => $year,
            'base_salary' => $calc['base_salary'],
            'hra' => $calc['hra'],
            'special_allowance' => $calc['special_allowance'],
            'bonus' => $calc['bonus'],
            'gross_salary' => $calc['gross_salary'],
            'pf_deduction' => $calc['pf_deduction'],
            'esi_deduction' => $calc['esi_deduction'],
            'pt_deduction' => $calc['pt_deduction'],
            'tds_deduction' => $calc['tds_deduction'],
            'advance_deduction' => $calc['advance_deduction'],
            'other_deductions' => $calc['other_deductions'],
            'total_deductions' => $calc['total_deductions'],
            'net_salary' => $calc['net_salary'],
            'status' => 'draft',
            'created_at' => current_time('mysql')
        ]);

        return new WP_REST_Response(['success' => true, 'id' => $record_id, 'payslip_number' => $payslip_number, 'data' => $calc], 200);
    }

    public static function get_sales_register($request) {
        $filters = $request->get_params();
        $res = FFC_Registers::get_sales_register($filters);
        return new WP_REST_Response(['success' => true, 'data' => $res], 200);
    }

    public static function get_purchase_register($request) {
        $filters = $request->get_params();
        $res = FFC_Registers::get_purchase_register($filters);
        return new WP_REST_Response(['success' => true, 'data' => $res], 200);
    }

    public static function get_financial_summary($request) {
        $from = $request->get_param('from_date');
        $to = $request->get_param('to_date');
        $res = FFC_Reports::get_financial_summary($from, $to);
        return new WP_REST_Response(['success' => true, 'data' => $res], 200);
    }

    public static function submit_enquiry($request) {
        global $wpdb;
        $params = $request->get_json_params();
        $table = FFC_DB::get_table('enquiries');

        $id = 'enq_' . uniqid();
        $wpdb->insert($table, [
            'id' => $id,
            'name' => sanitize_text_field($params['name'] ?? ''),
            'email' => sanitize_email($params['email'] ?? ''),
            'phone' => sanitize_text_field($params['phone'] ?? ''),
            'company' => sanitize_text_field($params['company'] ?? ''),
            'service' => sanitize_text_field($params['service'] ?? ''),
            'budget' => sanitize_text_field($params['budget'] ?? ''),
            'message' => sanitize_textarea_field($params['message'] ?? ''),
            'source' => sanitize_text_field($params['source'] ?? 'website'),
            'status' => 'new',
            'created_at' => current_time('mysql')
        ]);

        return new WP_REST_Response(['success' => true, 'id' => $id, 'message' => 'Thank you! Your enquiry has been received.'], 200);
    }

    public static function get_enquiries() {
        global $wpdb;
        $table = FFC_DB::get_table('enquiries');
        $rows = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC", ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $rows], 200);
    }
}
