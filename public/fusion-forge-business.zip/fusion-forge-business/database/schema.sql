-- ==============================================================================
-- FUSION FORGE CREATIONS — WORDPRESS / MYSQL PRODUCTION ERP SCHEMA
-- Tables Prefix: wp_ffc_ (or your custom $wpdb->prefix . ffc_)
-- Engine: InnoDB, Charset: utf8mb4, Collate: utf8mb4_unicode_ci
-- ==============================================================================

-- 1. Roles and Granular RBAC Permissions
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_roles` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `permissions` LONGTEXT NOT NULL,
    `is_system` TINYINT(1) DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. User Profiles & 2FA Authentication
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_users` (
    `id` VARCHAR(64) NOT NULL,
    `wp_user_id` BIGINT(20) UNSIGNED DEFAULT NULL,
    `email` VARCHAR(191) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `role` VARCHAR(64) NOT NULL DEFAULT 'staff',
    `custom_permissions` LONGTEXT,
    `totp_secret` VARCHAR(128) DEFAULT NULL,
    `totp_enabled` TINYINT(1) DEFAULT 0,
    `status` VARCHAR(32) DEFAULT 'active',
    `avatar_url` TEXT,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Company & Seller Master Profile
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_seller_profile` (
    `id` VARCHAR(64) NOT NULL DEFAULT 'default_seller',
    `company_name` VARCHAR(255) NOT NULL,
    `legal_name` VARCHAR(255) DEFAULT NULL,
    `tagline` VARCHAR(255) DEFAULT NULL,
    `motto` VARCHAR(255) DEFAULT NULL,
    `email` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(64) NOT NULL,
    `website` VARCHAR(255) DEFAULT NULL,
    `address` TEXT NOT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `state` VARCHAR(100) DEFAULT NULL,
    `state_code` VARCHAR(10) DEFAULT NULL,
    `postal_code` VARCHAR(20) DEFAULT NULL,
    `gstin` VARCHAR(30) DEFAULT NULL,
    `pan` VARCHAR(20) DEFAULT NULL,
    `msme_reg` VARCHAR(64) DEFAULT NULL,
    `lut_number` VARCHAR(64) DEFAULT NULL,
    `lut_expiry` DATE DEFAULT NULL,
    `sac_code` VARCHAR(20) DEFAULT '998314',
    `bank_name` VARCHAR(150) DEFAULT NULL,
    `account_name` VARCHAR(200) DEFAULT NULL,
    `account_number` VARCHAR(64) DEFAULT NULL,
    `ifsc` VARCHAR(30) DEFAULT NULL,
    `branch` VARCHAR(150) DEFAULT NULL,
    `upi_id` VARCHAR(150) DEFAULT NULL,
    `qr_string` TEXT DEFAULT NULL,
    `logo_url` LONGTEXT DEFAULT NULL,
    `signature_url` LONGTEXT DEFAULT NULL,
    `stamp_url` LONGTEXT DEFAULT NULL,
    `quotation_terms` LONGTEXT DEFAULT NULL,
    `invoice_terms` LONGTEXT DEFAULT NULL,
    `default_validity_days` INT DEFAULT 30,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Buyer & Client Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_clients` (
    `id` VARCHAR(64) NOT NULL,
    `client_code` VARCHAR(64) DEFAULT NULL,
    `name` VARCHAR(150) NOT NULL,
    `company` VARCHAR(200) DEFAULT NULL,
    `email` VARCHAR(191) DEFAULT NULL,
    `phone` VARCHAR(64) DEFAULT NULL,
    `billing_address` TEXT DEFAULT NULL,
    `shipping_address` TEXT DEFAULT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `state` VARCHAR(100) DEFAULT NULL,
    `state_code` VARCHAR(10) DEFAULT NULL,
    `pincode` VARCHAR(20) DEFAULT NULL,
    `gstin` VARCHAR(30) DEFAULT NULL,
    `pan` VARCHAR(20) DEFAULT NULL,
    `place_of_supply` VARCHAR(100) DEFAULT NULL,
    `payment_terms` VARCHAR(100) DEFAULT '100% Advance',
    `credit_limit` DECIMAL(15,2) DEFAULT 0.00,
    `opening_balance` DECIMAL(15,2) DEFAULT 0.00,
    `status` VARCHAR(32) DEFAULT 'active',
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Supplier Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_suppliers` (
    `id` VARCHAR(64) NOT NULL,
    `supplier_code` VARCHAR(64) DEFAULT NULL,
    `name` VARCHAR(150) NOT NULL,
    `company_name` VARCHAR(200) DEFAULT NULL,
    `email` VARCHAR(191) DEFAULT NULL,
    `phone` VARCHAR(64) DEFAULT NULL,
    `address` TEXT DEFAULT NULL,
    `city` VARCHAR(100) DEFAULT NULL,
    `state` VARCHAR(100) DEFAULT NULL,
    `state_code` VARCHAR(10) DEFAULT NULL,
    `pincode` VARCHAR(20) DEFAULT NULL,
    `gstin` VARCHAR(30) DEFAULT NULL,
    `pan` VARCHAR(20) DEFAULT NULL,
    `opening_balance` DECIMAL(15,2) DEFAULT 0.00,
    `payment_terms` VARCHAR(100) DEFAULT 'Net 30',
    `status` VARCHAR(32) DEFAULT 'active',
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Units of Measurement Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_units` (
    `id` VARCHAR(32) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `symbol` VARCHAR(20) NOT NULL,
    `is_decimal` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. HSN / SAC Code Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_hsn_master` (
    `id` VARCHAR(64) NOT NULL,
    `code` VARCHAR(30) NOT NULL,
    `type` VARCHAR(20) DEFAULT 'SAC',
    `description` TEXT NOT NULL,
    `gst_rate` DECIMAL(5,2) NOT NULL DEFAULT 18.00,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Goods & Services Items Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_goods_items` (
    `id` VARCHAR(64) NOT NULL,
    `item_code` VARCHAR(64) DEFAULT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `type` VARCHAR(32) DEFAULT 'service',
    `hsn_sac_code` VARCHAR(30) DEFAULT '998314',
    `unit` VARCHAR(32) DEFAULT 'NOS',
    `sale_price` DECIMAL(15,2) DEFAULT 0.00,
    `purchase_price` DECIMAL(15,2) DEFAULT 0.00,
    `gst_rate` DECIMAL(5,2) DEFAULT 18.00,
    `status` VARCHAR(32) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Configurable Document Numbering Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_document_numbering` (
    `id` VARCHAR(64) NOT NULL,
    `doc_type` VARCHAR(64) NOT NULL,
    `prefix` VARCHAR(32) NOT NULL,
    `suffix` VARCHAR(32) DEFAULT '',
    `padding_digits` INT NOT NULL DEFAULT 4,
    `use_financial_year` TINYINT(1) DEFAULT 1,
    `separator_char` VARCHAR(5) DEFAULT '/',
    `current_sequence` INT NOT NULL DEFAULT 0,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `doc_type_uniq` (`doc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Quotations & Project Scopes
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_quotations` (
    `id` VARCHAR(64) NOT NULL,
    `quotation_number` VARCHAR(100) NOT NULL,
    `client_id` VARCHAR(64) DEFAULT NULL,
    `client_name` VARCHAR(150) NOT NULL,
    `client_company` VARCHAR(200) DEFAULT NULL,
    `client_email` VARCHAR(191) DEFAULT NULL,
    `client_phone` VARCHAR(64) DEFAULT NULL,
    `client_address` TEXT DEFAULT NULL,
    `client_gstin` VARCHAR(30) DEFAULT NULL,
    `place_of_supply` VARCHAR(100) DEFAULT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `items` LONGTEXT NOT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `taxable_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `cgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `sgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `utgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `igst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_tax` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_terms` VARCHAR(100) DEFAULT '100% Advance',
    `validity_days` INT DEFAULT 30,
    `status` VARCHAR(32) DEFAULT 'draft',
    `terms` TEXT DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `converted_invoice_id` VARCHAR(64) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `quotation_number_uniq` (`quotation_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. GST Tax Invoices
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_invoices` (
    `id` VARCHAR(64) NOT NULL,
    `invoice_number` VARCHAR(100) NOT NULL,
    `quotation_id` VARCHAR(64) DEFAULT NULL,
    `client_id` VARCHAR(64) DEFAULT NULL,
    `client_name` VARCHAR(150) NOT NULL,
    `client_company` VARCHAR(200) DEFAULT NULL,
    `client_email` VARCHAR(191) DEFAULT NULL,
    `client_phone` VARCHAR(64) DEFAULT NULL,
    `client_address` TEXT DEFAULT NULL,
    `client_gstin` VARCHAR(30) DEFAULT NULL,
    `place_of_supply` VARCHAR(100) DEFAULT NULL,
    `issue_date` DATE NOT NULL,
    `due_date` DATE DEFAULT NULL,
    `items` LONGTEXT NOT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `taxable_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `cgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `sgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `utgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `igst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_tax` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `amount_paid` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_due` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status` VARCHAR(32) DEFAULT 'unpaid',
    `reverse_charge` TINYINT(1) DEFAULT 0,
    `irn` VARCHAR(128) DEFAULT NULL,
    `ack_no` VARCHAR(64) DEFAULT NULL,
    `ack_date` DATETIME DEFAULT NULL,
    `qr_data` TEXT DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `terms` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `invoice_number_uniq` (`invoice_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Payment Receipts
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_payments` (
    `id` VARCHAR(64) NOT NULL,
    `receipt_number` VARCHAR(100) NOT NULL,
    `invoice_id` VARCHAR(64) DEFAULT NULL,
    `invoice_number` VARCHAR(100) DEFAULT NULL,
    `client_id` VARCHAR(64) DEFAULT NULL,
    `client_name` VARCHAR(150) NOT NULL,
    `client_company` VARCHAR(200) DEFAULT NULL,
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_date` DATE NOT NULL,
    `payment_mode` VARCHAR(50) DEFAULT 'Bank Transfer',
    `transaction_ref` VARCHAR(100) DEFAULT NULL,
    `bank_account` VARCHAR(100) DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `receipt_number_uniq` (`receipt_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Credit & Debit Notes
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_credit_debit_notes` (
    `id` VARCHAR(64) NOT NULL,
    `note_number` VARCHAR(100) NOT NULL,
    `note_type` VARCHAR(20) NOT NULL,
    `party_type` VARCHAR(20) NOT NULL DEFAULT 'client',
    `party_id` VARCHAR(64) DEFAULT NULL,
    `party_name` VARCHAR(150) NOT NULL,
    `party_gstin` VARCHAR(30) DEFAULT NULL,
    `reference_doc_type` VARCHAR(50) DEFAULT 'invoice',
    `reference_doc_number` VARCHAR(100) DEFAULT NULL,
    `reference_doc_date` DATE DEFAULT NULL,
    `note_date` DATE NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `items` LONGTEXT NOT NULL,
    `taxable_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `cgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `sgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `utgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `igst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_tax` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status` VARCHAR(32) DEFAULT 'issued',
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `note_number_uniq` (`note_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Purchase Orders & Purchases (Bills)
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_purchases` (
    `id` VARCHAR(64) NOT NULL,
    `doc_type` VARCHAR(32) NOT NULL DEFAULT 'bill',
    `doc_number` VARCHAR(100) NOT NULL,
    `supplier_id` VARCHAR(64) DEFAULT NULL,
    `supplier_name` VARCHAR(150) NOT NULL,
    `supplier_company` VARCHAR(200) DEFAULT NULL,
    `supplier_gstin` VARCHAR(30) DEFAULT NULL,
    `bill_date` DATE NOT NULL,
    `due_date` DATE DEFAULT NULL,
    `items` LONGTEXT NOT NULL,
    `taxable_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `cgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `sgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `utgst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `igst_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_tax` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `amount_paid` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_status` VARCHAR(32) DEFAULT 'unpaid',
    `itc_eligible` TINYINT(1) DEFAULT 1,
    `reverse_charge` TINYINT(1) DEFAULT 0,
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `doc_number_uniq` (`doc_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. Operating Expenses
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_expenses` (
    `id` VARCHAR(64) NOT NULL,
    `expense_code` VARCHAR(64) DEFAULT NULL,
    `category` VARCHAR(100) NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `tax_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `expense_date` DATE NOT NULL,
    `paid_to` VARCHAR(150) DEFAULT NULL,
    `payment_mode` VARCHAR(50) DEFAULT 'Bank Transfer',
    `receipt_url` TEXT DEFAULT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. Staff Master
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_staff` (
    `id` VARCHAR(64) NOT NULL,
    `employee_code` VARCHAR(64) NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) DEFAULT NULL,
    `phone` VARCHAR(64) DEFAULT NULL,
    `designation` VARCHAR(100) NOT NULL,
    `department` VARCHAR(100) DEFAULT 'Engineering',
    `joining_date` DATE NOT NULL,
    `pan` VARCHAR(20) DEFAULT NULL,
    `bank_account_name` VARCHAR(150) DEFAULT NULL,
    `bank_name` VARCHAR(150) DEFAULT NULL,
    `account_number` VARCHAR(64) DEFAULT NULL,
    `ifsc` VARCHAR(30) DEFAULT NULL,
    `base_salary` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `hra` DECIMAL(15,2) DEFAULT 0.00,
    `special_allowance` DECIMAL(15,2) DEFAULT 0.00,
    `pf_applicable` TINYINT(1) DEFAULT 0,
    `esi_applicable` TINYINT(1) DEFAULT 0,
    `tds_applicable` TINYINT(1) DEFAULT 0,
    `status` VARCHAR(32) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `emp_code_uniq` (`employee_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. Staff Daily Attendance
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_attendance` (
    `id` VARCHAR(64) NOT NULL,
    `staff_id` VARCHAR(64) NOT NULL,
    `attendance_date` DATE NOT NULL,
    `status` VARCHAR(20) NOT NULL DEFAULT 'present',
    `check_in` TIME DEFAULT NULL,
    `check_out` TIME DEFAULT NULL,
    `remarks` TEXT DEFAULT NULL,
    `updated_by` VARCHAR(64) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `staff_date_uniq` (`staff_id`, `attendance_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Staff Payroll & Payslips
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_salary_records` (
    `id` VARCHAR(64) NOT NULL,
    `payslip_number` VARCHAR(100) NOT NULL,
    `staff_id` VARCHAR(64) NOT NULL,
    `month` INT NOT NULL,
    `year` INT NOT NULL,
    `base_salary` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `hra` DECIMAL(15,2) DEFAULT 0.00,
    `special_allowance` DECIMAL(15,2) DEFAULT 0.00,
    `bonus` DECIMAL(15,2) DEFAULT 0.00,
    `gross_salary` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `pf_deduction` DECIMAL(15,2) DEFAULT 0.00,
    `esi_deduction` DECIMAL(15,2) DEFAULT 0.00,
    `pt_deduction` DECIMAL(15,2) DEFAULT 0.00,
    `tds_deduction` DECIMAL(15,2) DEFAULT 0.00,
    `advance_deduction` DECIMAL(15,2) DEFAULT 0.00,
    `other_deductions` DECIMAL(15,2) DEFAULT 0.00,
    `total_deductions` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `net_salary` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `payment_date` DATE DEFAULT NULL,
    `payment_mode` VARCHAR(50) DEFAULT 'Bank Transfer',
    `transaction_ref` VARCHAR(100) DEFAULT NULL,
    `status` VARCHAR(32) DEFAULT 'draft',
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `payslip_num_uniq` (`payslip_number`),
    UNIQUE KEY `staff_month_year_uniq` (`staff_id`, `month`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. Lead Enquiries Table
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_enquiries` (
    `id` VARCHAR(64) NOT NULL,
    `name` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `phone` VARCHAR(64) DEFAULT NULL,
    `company` VARCHAR(200) DEFAULT NULL,
    `service` VARCHAR(100) DEFAULT NULL,
    `budget` VARCHAR(100) DEFAULT NULL,
    `message` TEXT NOT NULL,
    `source` VARCHAR(100) DEFAULT 'website',
    `status` VARCHAR(32) DEFAULT 'new',
    `notes` TEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 20. Audit Trail Logs
CREATE TABLE IF NOT EXISTS `{wpdb_prefix}ffc_audit_logs` (
    `id` VARCHAR(64) NOT NULL,
    `user_id` VARCHAR(64) DEFAULT NULL,
    `user_email` VARCHAR(191) DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `module` VARCHAR(64) NOT NULL,
    `entity_id` VARCHAR(64) DEFAULT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
