<?php
/**
 * Database Management Class
 */

class FFC_DB {

    public static function init() {
        // DB hooks if needed
    }

    public static function get_table($name) {
        global $wpdb;
        return $wpdb->prefix . 'ffc_' . $name;
    }

    public static function get_seller_profile() {
        global $wpdb;
        $table = self::get_table('seller_profile');
        $row = $wpdb->get_row("SELECT * FROM $table WHERE id = 'default_seller'", ARRAY_A);
        if (!$row) {
            // Fallback default
            return [
                'id' => 'default_seller',
                'company_name' => 'Fusion Forge Creations',
                'legal_name' => 'Fusion Forge Creations',
                'tagline' => 'Where Ideas Fuse With Technology',
                'motto' => 'INNOVATE • BUILD • AUTOMATE • GROW',
                'email' => 'admin@fusionforgecreation.com',
                'phone' => '+91 9033008720',
                'website' => 'https://fusionforgecreation.com',
                'address' => 'Flat No H2/203, Yogi Milan, Near Ring Road, Amli, Silvassa, Dadra & Nagar Haveli - 396230',
                'city' => 'Silvassa',
                'state' => 'Dadra & Nagar Haveli and Daman & Diu',
                'state_code' => '26',
                'postal_code' => '396230',
                'gstin' => '',
                'pan' => '',
                'sac_code' => '998314',
                'bank_name' => 'State Bank of India',
                'account_name' => 'Fusion Forge Creations',
                'account_number' => '',
                'ifsc' => '',
                'branch' => 'Silvassa Main',
                'upi_id' => 'admin@fusionforgecreation',
                'default_validity_days' => 30
            ];
        }
        return $row;
    }

    public static function update_seller_profile($data) {
        global $wpdb;
        $table = self::get_table('seller_profile');
        $existing = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE id = 'default_seller'");
        if ($existing) {
            return $wpdb->update($table, $data, ['id' => 'default_seller']);
        } else {
            $data['id'] = 'default_seller';
            return $wpdb->insert($table, $data);
        }
    }

    public static function log_audit($action, $module, $entity_id = null, $details = null, $user_id = null, $user_email = null) {
        global $wpdb;
        $table = self::get_table('audit_logs');
        $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
        
        $wpdb->insert($table, [
            'id' => 'audit_' . uniqid(),
            'user_id' => $user_id,
            'user_email' => $user_email,
            'action' => sanitize_text_field($action),
            'module' => sanitize_text_field($module),
            'entity_id' => $entity_id ? sanitize_text_field($entity_id) : null,
            'details' => is_array($details) || is_object($details) ? json_encode($details) : sanitize_textarea_field($details),
            'ip_address' => $ip,
            'created_at' => current_time('mysql')
        ]);
    }
}
