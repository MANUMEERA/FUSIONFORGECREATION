<?php
/**
 * WordPress Admin Menu & Settings Controller
 */

class FFC_Admin {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_admin_menus']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
    }

    public static function register_admin_menus() {
        $capability = 'manage_options';

        // Main Menu
        add_menu_page(
            'Fusion Forge ERP',
            'Fusion Forge ERP',
            $capability,
            'fusion-forge-erp',
            [__CLASS__, 'render_admin_app'],
            'dashicons-chart-pie',
            30
        );

        // Submenus
        add_submenu_page(
            'fusion-forge-erp',
            'Dashboard',
            'Dashboard',
            $capability,
            'fusion-forge-erp',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Quotations',
            'Quotations',
            $capability,
            'ffc-quotations',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Tax Invoices',
            'Tax Invoices',
            $capability,
            'ffc-invoices',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Payment Receipts',
            'Payment Receipts',
            $capability,
            'ffc-payments',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Credit & Debit Notes',
            'Credit & Debit Notes',
            $capability,
            'ffc-notes',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Clients & Ledgers',
            'Clients & Ledgers',
            $capability,
            'ffc-clients',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Purchases & Bills',
            'Purchases',
            $capability,
            'ffc-purchases',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Operating Expenses',
            'Expenses',
            $capability,
            'ffc-expenses',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Staff & Payroll',
            'Staff & Payroll',
            $capability,
            'ffc-payroll',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Registers & Reports',
            'Reports & Registers',
            $capability,
            'ffc-reports',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Agency Settings',
            'Agency Settings',
            $capability,
            'ffc-settings',
            [__CLASS__, 'render_admin_app']
        );

        add_submenu_page(
            'fusion-forge-erp',
            'Audit Trail',
            'Audit Trail',
            $capability,
            'ffc-audit',
            [__CLASS__, 'render_admin_app']
        );
    }

    public static function enqueue_admin_assets($hook) {
        if (strpos($hook, 'ffc') === false && strpos($hook, 'fusion-forge') === false) {
            return;
        }

        // Pass REST API config and nonce to client-side scripts
        wp_localize_script('jquery', 'ffcConfig', [
            'api_base' => esc_url_raw(rest_url('ffc/v1')),
            'nonce' => wp_create_nonce('wp_rest'),
            'current_user' => wp_get_current_user(),
            'site_url' => get_site_url()
        ]);
    }

    public static function render_admin_app() {
        $seller = FFC_DB::get_seller_profile();
        $summary = FFC_Reports::get_financial_summary();
        $page = $_GET['page'] ?? 'fusion-forge-erp';
        ?>
        <div class="wrap" style="max-width: 1300px; margin: 20px auto 40px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            <div style="background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%); color: #fff; padding: 24px 30px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.15); display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1 style="color: #fff; margin: 0; font-size: 24px; font-weight: 800;"><?php echo esc_html($seller['company_name'] ?? 'Fusion Forge Creations'); ?> — ERP</h1>
                    <p style="margin: 4px 0 0 0; color: #a5b4fc; font-size: 13px;"><?php echo esc_html($seller['tagline'] ?? 'Where Ideas Fuse With Technology'); ?> • Complete Business Operating System</p>
                </div>
                <div style="text-align: right;">
                    <span style="background: #312e81; color: #e0e7ff; font-size: 12px; font-weight: 700; padding: 6px 12px; border-radius: 6px; border: 1px solid #4338ca;">
                        GST Registered: <?php echo esc_html($seller['gstin'] ?: 'Not configured'); ?>
                    </span>
                </div>
            </div>

            <!-- Quick Metrics Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
                <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 18px;">
                    <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Invoiced Sales</div>
                    <div style="font-size: 22px; font-weight: 800; color: #0f172a; margin-top: 4px;">₹<?php echo number_format($summary['total_sales_with_tax'], 2); ?></div>
                    <div style="font-size: 11px; color: #059669; margin-top: 4px;">Taxable: ₹<?php echo number_format($summary['gross_sales_taxable'], 2); ?></div>
                </div>

                <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 18px;">
                    <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">Outstanding Receivables</div>
                    <div style="font-size: 22px; font-weight: 800; color: #dc2626; margin-top: 4px;">₹<?php echo number_format($summary['total_receivables_due'], 2); ?></div>
                    <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Collected: ₹<?php echo number_format($summary['total_collected'], 2); ?></div>
                </div>

                <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 18px;">
                    <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Expenses & Purchases</div>
                    <div style="font-size: 22px; font-weight: 800; color: #d97706; margin-top: 4px;">₹<?php echo number_format($summary['total_purchases'] + $summary['total_operating_expenses'], 2); ?></div>
                    <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Direct + Ops Costs</div>
                </div>

                <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 18px;">
                    <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">Operating Net Margin</div>
                    <div style="font-size: 22px; font-weight: 800; color: #8e2d9d; margin-top: 4px;"><?php echo $summary['net_profit_margin']; ?>%</div>
                    <div style="font-size: 11px; color: #059669; margin-top: 4px;">Operating Profit: ₹<?php echo number_format($summary['operating_profit'], 2); ?></div>
                </div>
            </div>

            <!-- Main Content Container -->
            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 16px; margin-bottom: 20px;">
                    <div>
                        <h2 style="margin: 0; font-size: 18px; font-weight: 800; color: #1e293b;">
                            <?php 
                                echo esc_html(ucwords(str_replace(['ffc-', '-', 'fusion forge erp'], [' ', ' ', 'Executive Dashboard'], $page))); 
                            ?>
                        </h2>
                        <p style="margin: 2px 0 0 0; font-size: 12px; color: #64748b;">Manage GST-compliant records, automated numbering, and accounts seamlessly.</p>
                    </div>
                    <div>
                        <a href="<?php echo esc_url(rest_url('ffc/v1/reports/summary')); ?>" target="_blank" class="button button-primary" style="background: #8e2d9d; border-color: #7c248b;">
                            API Live Endpoint
                        </a>
                    </div>
                </div>

                <div id="ffc-app-root">
                    <p style="color: #475569; font-size: 14px; line-height: 1.6;">
                        Welcome to the <strong>Fusion Forge Business Operating System</strong> WordPress plugin. All REST API endpoints (<code>/wp-json/ffc/v1/*</code>) and 20 database tables (<code><?php echo esc_html($GLOBALS['wpdb']->prefix); ?>ffc_*</code>) are fully active and connected.
                    </p>
                    <div style="background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 18px; margin-top: 16px;">
                        <div style="font-weight: 700; font-size: 13px; color: #334155; margin-bottom: 6px;">Active Plugin Services & Handlers:</div>
                        <ul style="margin: 0; padding-left: 20px; font-size: 12px; color: #64748b; line-height: 1.8;">
                            <li><strong>GST Engine:</strong> Intra-state CGST+SGST / UTGST (Dadra & Nagar Haveli 26) & Inter-state IGST calculation.</li>
                            <li><strong>Document Numbering:</strong> Auto-incrementing FY sequence (e.g. <code>FFC/INV/2026-27/0001</code>).</li>
                            <li><strong>Unified Document Engine:</strong> Quotations, Tax Invoices, Payment Receipts, Credit Notes, Debit Notes, and Purchase Orders.</li>
                            <li><strong>Accounting & Ledgers:</strong> Real-time Buyer Ledger, Supplier Ledger, Sales Register, and Purchase Register.</li>
                            <li><strong>Staff Payroll:</strong> Attendance tracking and monthly salary calculations with statutory deductions (PF, ESI, PT, TDS).</li>
                            <li><strong>Integrations:</strong> WhatsApp message generator, SMTP/wp_mail dispatch, and TOTP 2FA Google Authenticator.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
