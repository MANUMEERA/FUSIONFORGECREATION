<?php
/**
 * Configurable Document Numbering Engine
 */

class FFC_Numbering {

    /**
     * Gets the current Indian Financial Year string (e.g. 2026-27)
     */
    public static function get_financial_year($date_str = null) {
        $timestamp = $date_str ? strtotime($date_str) : time();
        $year = intval(date('Y', $timestamp));
        $month = intval(date('n', $timestamp));

        if ($month < 4) {
            $start_year = $year - 1;
            $end_year = $year;
        } else {
            $start_year = $year;
            $end_year = $year + 1;
        }

        return $start_year . '-' . substr($end_year, -2);
    }

    /**
     * Generates next document number and increments sequence safely
     */
    public static function generate_next_number($doc_type, $date_str = null) {
        global $wpdb;

        $table = FFC_DB::get_table('document_numbering');
        $config = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE doc_type = %s", $doc_type), ARRAY_A);

        if (!$config) {
            $prefix = strtoupper(substr($doc_type, 0, 3));
            $padding = 4;
            $use_fy = 1;
            $sep = '/';
            $seq = 1;
            $wpdb->insert($table, [
                'id' => 'num_' . $doc_type,
                'doc_type' => $doc_type,
                'prefix' => 'FFC/' . $prefix,
                'padding_digits' => $padding,
                'use_financial_year' => $use_fy,
                'separator_char' => $sep,
                'current_sequence' => 1
            ]);
        } else {
            $prefix = $config['prefix'];
            $padding = intval($config['padding_digits'] ?: 4);
            $use_fy = intval($config['use_financial_year']);
            $sep = $config['separator_char'] ?: '/';
            $seq = intval($config['current_sequence']) + 1;

            $wpdb->update($table, ['current_sequence' => $seq], ['doc_type' => $doc_type]);
        }

        $formatted_seq = str_pad($seq, $padding, '0', STR_PAD_LEFT);

        if ($use_fy) {
            $fy = self::get_financial_year($date_str);
            return $prefix . $sep . $fy . $sep . $formatted_seq;
        }

        return $prefix . $sep . $formatted_seq;
    }
}
