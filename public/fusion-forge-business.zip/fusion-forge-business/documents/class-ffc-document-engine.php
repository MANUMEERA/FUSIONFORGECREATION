<?php
/**
 * Common Unified Document Engine for Fusion Forge Creations
 * Generates Quotations, Tax Invoices, Payment Receipts, Purchase Orders, Credit Notes & Debit Notes
 */

class FFC_Document_Engine {

    /**
     * Convert numbers to words in Indian numbering format (Lakhs, Crores)
     */
    public static function number_to_words($num) {
        $num = floatval(str_replace(',', '', $num));
        if ($num == 0) return 'Zero Rupees Only';

        $ones = [
            0 => '', 1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five',
            6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten',
            11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
            16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen', 19 => 'Nineteen'
        ];

        $tens = [
            2 => 'Twenty', 3 => 'Thirty', 4 => 'Forty', 5 => 'Fifty',
            6 => 'Sixty', 7 => 'Seventy', 8 => 'Eighty', 9 => 'Ninety'
        ];

        $convert_triplet = function($n) use ($ones, $tens) {
            $str = '';
            if ($n >= 100) {
                $str .= $ones[intval($n / 100)] . ' Hundred ';
                $n %= 100;
            }
            if ($n >= 20) {
                $str .= $tens[intval($n / 10)] . ' ';
                $n %= 10;
            }
            if ($n > 0) {
                $str .= $ones[$n] . ' ';
            }
            return trim($str);
        };

        $rupees = floor($num);
        $paise = round(($num - $rupees) * 100);

        $parts = [];
        // Crores (>= 10,000,000)
        if ($rupees >= 10000000) {
            $crores = floor($rupees / 10000000);
            $parts[] = $convert_triplet($crores) . ' Crore';
            $rupees %= 10000000;
        }
        // Lakhs (>= 100,000)
        if ($rupees >= 100000) {
            $lakhs = floor($rupees / 100000);
            $parts[] = $convert_triplet($lakhs) . ' Lakh';
            $rupees %= 100000;
        }
        // Thousands (>= 1,000)
        if ($rupees >= 1000) {
            $thousands = floor($rupees / 1000);
            $parts[] = $convert_triplet($thousands) . ' Thousand';
            $rupees %= 1000;
        }
        // Hundreds & Units
        if ($rupees > 0) {
            $parts[] = $convert_triplet($rupees);
        }

        $result = implode(' ', array_filter($parts)) . ' Rupees';
        if ($paise > 0) {
            $result .= ' and ' . $convert_triplet($paise) . ' Paise';
        }
        return trim($result) . ' Only';
    }

    /**
     * Renders standard HTML for any business document
     */
    public static function render_document_html($doc_type, $doc_data, $seller_profile = null) {
        if (!$seller_profile) {
            $seller_profile = FFC_DB::get_seller_profile();
        }

        $titles = [
            'quotation' => 'FORMAL QUOTATION & SCOPE',
            'invoice' => 'TAX INVOICE',
            'payment_receipt' => 'OFFICIAL PAYMENT RECEIPT',
            'purchase_order' => 'PURCHASE ORDER',
            'credit_note' => 'CREDIT NOTE',
            'debit_note' => 'DEBIT NOTE'
        ];

        $doc_title = $titles[$doc_type] ?? strtoupper(str_replace('_', ' ', $doc_type));
        $grand_total = floatval($doc_data['total_amount'] ?? $doc_data['amount'] ?? 0);
        $amount_in_words = self::number_to_words($grand_total);
        $items = !empty($doc_data['items']) ? (is_array($doc_data['items']) ? $doc_data['items'] : json_decode($doc_data['items'], true)) : [];

        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title><?php echo esc_attr($doc_title . ' - ' . ($doc_data['doc_number'] ?? $doc_data['invoice_number'] ?? $doc_data['quotation_number'] ?? $doc_data['receipt_number'] ?? $doc_data['note_number'] ?? '')); ?></title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 13px; color: #1e293b; background: #fff; line-height: 1.5; padding: 30px; }
                .doc-card { max-width: 800px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; padding: 32px; background: #fff; }
                .header-flex { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #8e2d9d; padding-bottom: 20px; margin-bottom: 24px; }
                .brand-title { font-size: 24px; font-weight: 800; color: #8e2d9d; letter-spacing: -0.5px; }
                .brand-tagline { font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; margin-top: 2px; }
                .seller-meta { font-size: 11px; color: #475569; margin-top: 8px; line-height: 1.4; }
                .doc-badge-box { text-align: right; }
                .doc-type-pill { display: inline-block; background: #f3e8ff; color: #8e2d9d; font-size: 13px; font-weight: 800; padding: 6px 14px; border-radius: 20px; border: 1px solid #d8b4fe; letter-spacing: 0.5px; }
                .doc-num { font-size: 15px; font-family: monospace; font-weight: 700; color: #0f172a; margin-top: 8px; }
                .doc-date { font-size: 12px; color: #64748b; margin-top: 4px; }
                .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
                .meta-panel { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; }
                .panel-heading { font-size: 10px; font-weight: 800; text-transform: uppercase; color: #8e2d9d; letter-spacing: 0.5px; margin-bottom: 6px; }
                .party-name { font-size: 14px; font-weight: 700; color: #0f172a; }
                .party-details { font-size: 11px; color: #475569; margin-top: 4px; line-height: 1.4; }
                table.items-table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
                table.items-table th { background: #f1f5f9; color: #334155; font-size: 11px; font-weight: 700; text-transform: uppercase; padding: 10px 12px; border-bottom: 2px solid #cbd5e1; text-align: left; }
                table.items-table td { padding: 10px 12px; border-bottom: 1px solid #e2e8f0; font-size: 12px; }
                .text-right { text-align: right; }
                .text-center { text-align: center; }
                .totals-section { display: flex; justify-content: flex-end; margin-bottom: 24px; }
                .totals-box { width: 320px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; }
                .totals-row { display: flex; justify-content: space-between; font-size: 12px; padding: 4px 0; color: #475569; }
                .totals-row.grand { border-top: 2px solid #8e2d9d; margin-top: 6px; padding-top: 8px; font-size: 14px; font-weight: 800; color: #8e2d9d; }
                .words-box { background: #faf5ff; border: 1px dashed #d8b4fe; border-radius: 6px; padding: 10px 14px; margin-bottom: 24px; font-size: 11px; color: #6b21a8; }
                .bank-terms-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; font-size: 11px; }
                .signature-box { text-align: right; margin-top: 30px; }
                .signature-img { max-height: 50px; margin-bottom: 4px; }
                .stamp-img { max-height: 70px; margin-bottom: 4px; }
                .footer-bar { border-top: 1px solid #e2e8f0; padding-top: 12px; text-align: center; font-size: 10px; color: #94a3b8; }
                @media print {
                    body { padding: 0; }
                    .doc-card { border: none; padding: 0; }
                    .no-print { display: none; }
                }
            </style>
        </head>
        <body>
            <div class="doc-card">
                <!-- Header -->
                <div class="header-flex">
                    <div>
                        <div class="brand-title"><?php echo esc_html($seller_profile['company_name'] ?? 'Fusion Forge Creations'); ?></div>
                        <div class="brand-tagline"><?php echo esc_html($seller_profile['tagline'] ?? 'Where Ideas Fuse With Technology'); ?></div>
                        <div class="seller-meta">
                            <?php echo esc_html($seller_profile['address'] ?? ''); ?><br/>
                            <?php if (!empty($seller_profile['gstin'])): ?>GSTIN: <strong><?php echo esc_html($seller_profile['gstin']); ?></strong> | <?php endif; ?>
                            <?php if (!empty($seller_profile['pan'])): ?>PAN: <strong><?php echo esc_html($seller_profile['pan']); ?></strong> | <?php endif; ?>
                            SAC: <strong><?php echo esc_html($seller_profile['sac_code'] ?? '998314'); ?></strong><br/>
                            Email: <?php echo esc_html($seller_profile['email'] ?? 'admin@fusionforgecreation.com'); ?> | Phone: <?php echo esc_html($seller_profile['phone'] ?? '+91 9033008720'); ?><br/>
                            Web: <?php echo esc_html(str_replace(['https://', 'http://'], '', $seller_profile['website'] ?? 'fusionforgecreation.com')); ?>
                        </div>
                    </div>
                    <div class="doc-badge-box">
                        <div class="doc-type-pill"><?php echo esc_html($doc_title); ?></div>
                        <div class="doc-num"><?php echo esc_html($doc_data['doc_number'] ?? $doc_data['invoice_number'] ?? $doc_data['quotation_number'] ?? $doc_data['receipt_number'] ?? $doc_data['note_number'] ?? ''); ?></div>
                        <div class="doc-date">Date: <strong><?php echo esc_html($doc_data['issue_date'] ?? $doc_data['payment_date'] ?? $doc_data['note_date'] ?? $doc_data['created_at'] ?? date('d-M-Y')); ?></strong></div>
                    </div>
                </div>

                <!-- Buyer / Supplier Meta -->
                <div class="meta-grid">
                    <div class="meta-panel">
                        <div class="panel-heading">Billed To / Party Details</div>
                        <div class="party-name"><?php echo esc_html($doc_data['client_name'] ?? $doc_data['supplier_name'] ?? $doc_data['party_name'] ?? 'Valued Client'); ?></div>
                        <?php if (!empty($doc_data['client_company'] ?? $doc_data['supplier_company'])): ?>
                            <div style="font-weight:600; font-size:12px; color:#1e293b;"><?php echo esc_html($doc_data['client_company'] ?? $doc_data['supplier_company']); ?></div>
                        <?php endif; ?>
                        <div class="party-details">
                            <?php echo nl2br(esc_html($doc_data['client_address'] ?? $doc_data['supplier_address'] ?? $doc_data['billing_address'] ?? '')); ?><br/>
                            <?php if (!empty($doc_data['client_gstin'] ?? $doc_data['supplier_gstin'] ?? $doc_data['party_gstin'])): ?>
                                GSTIN: <strong><?php echo esc_html($doc_data['client_gstin'] ?? $doc_data['supplier_gstin'] ?? $doc_data['party_gstin']); ?></strong><br/>
                            <?php endif; ?>
                            <?php if (!empty($doc_data['place_of_supply'])): ?>
                                Place of Supply: <strong><?php echo esc_html($doc_data['place_of_supply']); ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="meta-panel">
                        <div class="panel-heading">Payment & Transaction Terms</div>
                        <div class="party-details" style="margin-top: 0;">
                            <strong>Payment Terms:</strong> <?php echo esc_html($doc_data['payment_terms'] ?? '100% Advance / Net 30'); ?><br/>
                            <?php if (!empty($doc_data['due_date'])): ?>
                                <strong>Due Date:</strong> <?php echo esc_html($doc_data['due_date']); ?><br/>
                            <?php endif; ?>
                            <?php if (!empty($doc_data['transaction_ref'])): ?>
                                <strong>Transaction UTR:</strong> <?php echo esc_html($doc_data['transaction_ref']); ?><br/>
                            <?php endif; ?>
                            <?php if (!empty($doc_data['payment_mode'])): ?>
                                <strong>Payment Mode:</strong> <?php echo esc_html($doc_data['payment_mode']); ?><br/>
                            <?php endif; ?>
                            <strong>Place of Jurisdiction:</strong> Silvassa (D&NH)
                        </div>
                    </div>
                </div>

                <!-- Line Items Table -->
                <?php if (!empty($items)): ?>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th style="width: 5%;">#</th>
                            <th style="width: 45%;">Description</th>
                            <th class="text-center" style="width: 12%;">HSN/SAC</th>
                            <th class="text-center" style="width: 10%;">Qty</th>
                            <th class="text-right" style="width: 13%;">Rate (₹)</th>
                            <th class="text-right" style="width: 15%;">Amount (₹)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td><?php echo $idx + 1; ?></td>
                            <td>
                                <strong><?php echo esc_html($item['title'] ?? $item['name'] ?? $item['description'] ?? 'Service Item'); ?></strong>
                                <?php if (!empty($item['description']) && ($item['title'] ?? '') !== $item['description']): ?>
                                    <div style="font-size: 11px; color: #64748b; margin-top: 2px;"><?php echo esc_html($item['description']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-center font-mono"><?php echo esc_html($item['hsn_sac'] ?? $item['sac'] ?? $seller_profile['sac_code'] ?? '998314'); ?></td>
                            <td class="text-center"><?php echo esc_html($item['quantity'] ?? $item['qty'] ?? 1); ?></td>
                            <td class="text-right"><?php echo number_format(floatval($item['rate'] ?? $item['price'] ?? 0), 2); ?></td>
                            <td class="text-right font-bold"><?php echo number_format(floatval($item['amount'] ?? (($item['quantity'] ?? 1) * ($item['rate'] ?? 0))), 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>

                <!-- Totals Breakdown -->
                <div class="totals-section">
                    <div class="totals-box">
                        <div class="totals-row">
                            <span>Taxable Subtotal:</span>
                            <strong>₹<?php echo number_format(floatval($doc_data['taxable_amount'] ?? $doc_data['subtotal'] ?? $grand_total), 2); ?></strong>
                        </div>
                        <?php if (floatval($doc_data['cgst_amount'] ?? 0) > 0): ?>
                        <div class="totals-row">
                            <span>CGST (9%):</span>
                            <span>₹<?php echo number_format(floatval($doc_data['cgst_amount']), 2); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (floatval($doc_data['sgst_amount'] ?? 0) > 0): ?>
                        <div class="totals-row">
                            <span>SGST (9%):</span>
                            <span>₹<?php echo number_format(floatval($doc_data['sgst_amount']), 2); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (floatval($doc_data['utgst_amount'] ?? 0) > 0): ?>
                        <div class="totals-row">
                            <span>UTGST (9%):</span>
                            <span>₹<?php echo number_format(floatval($doc_data['utgst_amount']), 2); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (floatval($doc_data['igst_amount'] ?? 0) > 0): ?>
                        <div class="totals-row">
                            <span>IGST (18%):</span>
                            <span>₹<?php echo number_format(floatval($doc_data['igst_amount']), 2); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="totals-row grand">
                            <span>Total Amount:</span>
                            <span>₹<?php echo number_format($grand_total, 2); ?></span>
                        </div>
                        <?php if (!empty($doc_data['amount_paid'])): ?>
                        <div class="totals-row" style="color: #059669; font-weight:600;">
                            <span>Amount Paid:</span>
                            <span>₹<?php echo number_format(floatval($doc_data['amount_paid']), 2); ?></span>
                        </div>
                        <div class="totals-row" style="color: #dc2626; font-weight:700;">
                            <span>Balance Due:</span>
                            <span>₹<?php echo number_format(floatval($doc_data['balance_due'] ?? ($grand_total - $doc_data['amount_paid'])), 2); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Amount in Words -->
                <div class="words-box">
                    <strong>Amount in Words:</strong> <?php echo esc_html($amount_in_words); ?>
                </div>

                <!-- Bank Details & Terms -->
                <div class="bank-terms-grid">
                    <div>
                        <div class="panel-heading">Bank Transfer Details</div>
                        <div style="line-height: 1.45; color: #475569;">
                            Bank Name: <strong><?php echo esc_html($seller_profile['bank_name'] ?? 'State Bank of India'); ?></strong><br/>
                            Account Name: <strong><?php echo esc_html($seller_profile['account_name'] ?? 'Fusion Forge Creations'); ?></strong><br/>
                            Account No: <strong><?php echo esc_html($seller_profile['account_number'] ?? 'To be provided'); ?></strong><br/>
                            IFSC Code: <strong><?php echo esc_html($seller_profile['ifsc'] ?? 'SBIN0000000'); ?></strong><br/>
                            UPI ID: <strong><?php echo esc_html($seller_profile['upi_id'] ?? 'admin@fusionforgecreation'); ?></strong>
                        </div>
                    </div>
                    <div>
                        <div class="panel-heading">Terms & Conditions</div>
                        <div style="font-size: 10.5px; color: #64748b; line-height: 1.4;">
                            <?php echo nl2br(esc_html($doc_data['terms'] ?? $seller_profile['invoice_terms'] ?? "1. Subject to Silvassa jurisdiction.\n2. Payment due as per agreed milestone.")); ?>
                        </div>
                    </div>
                </div>

                <!-- Signature and Stamp -->
                <div class="signature-box">
                    <div style="font-size: 11px; font-weight: 700; color: #334155; margin-bottom: 40px;">For <?php echo esc_html($seller_profile['company_name'] ?? 'Fusion Forge Creations'); ?></div>
                    <div style="font-size: 11px; font-weight: 700; color: #0f172a; border-top: 1px solid #cbd5e1; display: inline-block; padding-top: 4px;">Authorized Signatory</div>
                </div>

                <!-- Footer -->
                <div class="footer-bar">
                    This is a computer generated official business document issued by <?php echo esc_html($seller_profile['company_name'] ?? 'Fusion Forge Creations'); ?> • <?php echo esc_html($seller_profile['website'] ?? 'fusionforgecreation.com'); ?>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
}
